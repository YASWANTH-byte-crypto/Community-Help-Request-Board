/**
 * Frontend Interactive Controller for StudentLife Hack
 * Full REST API integration, reactive UI updates, SVG chart rendering.
 */

let currentPage = 1;
const pageSize = 8;
let searchTimeout = null;

document.addEventListener("DOMContentLoaded", () => {
  fetchStats();
  fetchCampusAlerts();
  fetchRequests();
  fetchWarnings();
});

// Toast Notifications
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerText = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 4000);
}

// Tab Switching
function switchTab(tabId) {
  document.querySelectorAll(".tab-pane").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".tab-btn").forEach(el => el.classList.remove("active"));

  const target = document.getElementById(tabId);
  if (target) target.classList.add("active");

  const btn = Array.from(document.querySelectorAll(".tab-btn")).find(b =>
    b.getAttribute("onclick").includes(tabId)
  );
  if (btn) btn.classList.add("active");

  if (tabId === "tab-analytics") {
    fetchStats(); // refresh charts
  } else if (tabId === "tab-triage") {
    renderTriageView();
  } else if (tabId === "tab-warnings") {
    fetchWarnings();
  }
}

// Campus Alerts Banner
async function fetchCampusAlerts() {
  try {
    const res = await fetch("/api/alerts");
    const json = await res.json();
    if (json.success && json.data && json.data.data) {
      const anns = json.data.data.campus_announcements || [];
      if (anns.length > 0) {
        document.getElementById("campus-announcement-text").innerText =
          `[${anns[0].level}] ${anns[0].title}`;
      }
    }
  } catch (e) {
    document.getElementById("campus-banner").style.display = "none";
  }
}

function dismissBanner() {
  document.getElementById("campus-banner").style.display = "none";
}

// Executive Stats & KPIs
async function fetchStats() {
  try {
    const res = await fetch("/api/stats");
    const json = await res.json();
    if (json.success) {
      const stats = json.data;
      document.getElementById("kpi-total").innerText = stats.total_records || 0;
      const activeCount = (stats.status_counts["Open"] || 0) + (stats.status_counts["In Progress"] || 0);
      document.getElementById("kpi-active").innerText = activeCount;
      document.getElementById("kpi-overdue").innerText = stats.overdue_count || 0;
      document.getElementById("kpi-avg-priority").innerText = (stats.average_priority || 0.0).toFixed(1);
      document.getElementById("kpi-warnings").innerText = stats.active_warnings_count || 0;

      // Render Dynamic SVG Charts
      renderSvgChart("chart-category-container", stats.category_counts || {}, "#3b82f6");
      renderSvgChart("chart-urgency-container", stats.urgency_counts || {}, "#ef4444");
    }
  } catch (err) {
    console.error("Failed to load statistics:", err);
  }
}

// Requests Listing & Pagination
async function fetchRequests() {
  const cat = document.getElementById("filter-category").value;
  const urg = document.getElementById("filter-urgency").value;
  const stat = document.getElementById("filter-status").value;
  const sort = document.getElementById("sort-order").value;
  const kw = document.getElementById("search-input").value.trim();

  const params = new URLSearchParams({
    page: currentPage,
    page_size: pageSize,
    order_by: sort
  });
  if (cat) params.append("category", cat);
  if (urg) params.append("urgency", urg);
  if (stat) params.append("status", stat);
  if (kw) params.append("keyword", kw);

  try {
    const res = await fetch(`/api/requests?${params.toString()}`);
    const json = await res.json();

    if (json.success) {
      renderTable(json.data);
      updatePagination(json.meta);
    }
  } catch (err) {
    console.error("Failed to load requests:", err);
  }
}

function renderTable(requests) {
  const tbody = document.getElementById("requests-tbody");
  tbody.innerHTML = "";

  if (!requests || requests.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-muted">No help requests matched your criteria.</td></tr>`;
    return;
  }

  requests.forEach(req => {
    const tr = document.createElement("tr");

    const urgBadgeClass = `badge-${req.urgency.toLowerCase()}`;
    const statBadgeClass = `badge-${req.status.toLowerCase().replace(" ", "")}`;
    const overdueBadge = req.is_overdue || (req.deadline && new Date(req.deadline) < new Date() && req.status !== "Resolved" && req.status !== "Cancelled")
      ? `<span class="badge-overdue">OVERDUE</span>`
      : "";

    tr.innerHTML = `
      <td><strong>#${req.id}</strong></td>
      <td>
        <div style="font-weight:600; color:#1e293b;">${escapeHtml(req.title)}</div>
        <div style="font-size:0.78rem; color:#64748b;">${escapeHtml(req.requester)} &bull; ${escapeHtml(req.location)}</div>
      </td>
      <td><span style="font-size:0.82rem; font-weight:500;">${escapeHtml(req.category)}</span></td>
      <td><span class="badge ${urgBadgeClass}">${escapeHtml(req.urgency)}</span></td>
      <td><span style="font-weight:700; color:#7c3aed;">${req.priority_score.toFixed(1)}</span></td>
      <td>
        <span class="badge ${statBadgeClass}">${escapeHtml(req.status)}</span>
        ${overdueBadge}
      </td>
      <td style="font-size:0.8rem;">${req.deadline || '<span class="text-muted">None</span>'}</td>
      <td>
        <button class="btn btn-outline btn-sm" onclick="inspectRequest(${req.id})">Details</button>
        ${req.status !== 'Resolved' ? `<button class="btn btn-success btn-sm" style="margin-left:4px;" onclick="quickResolve(${req.id})">Resolve</button>` : ''}
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function updatePagination(meta) {
  document.getElementById("current-page-display").innerText = meta.page;
  document.getElementById("pagination-info").innerText =
    `Showing Page ${meta.page} of ${meta.total_pages} (${meta.total_records} total)`;

  document.getElementById("btn-prev-page").disabled = meta.page <= 1;
  document.getElementById("btn-next-page").disabled = meta.page >= meta.total_pages;
}

function changePage(delta) {
  currentPage += delta;
  if (currentPage < 1) currentPage = 1;
  fetchRequests();
}

function handleSearchInput() {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    currentPage = 1;
    fetchRequests();
  }, 250);
}

function resetFilters() {
  document.getElementById("filter-category").value = "";
  document.getElementById("filter-urgency").value = "";
  document.getElementById("filter-status").value = "";
  document.getElementById("search-input").value = "";
  document.getElementById("sort-order").value = "priority_score DESC, id DESC";
  currentPage = 1;
  fetchRequests();
}

// Modal Controllers
function openCreateModal() {
  document.getElementById("modal-create").classList.add("show");
  document.getElementById("create-warning-banner").classList.add("hidden");
  document.getElementById("create-request-form").reset();
}

function closeCreateModal() {
  document.getElementById("modal-create").classList.remove("show");
}

function openBulkImportModal() {
  document.getElementById("modal-bulk").classList.add("show");
  document.getElementById("bulk-result-box").classList.add("hidden");
}

function closeBulkImportModal() {
  document.getElementById("modal-bulk").classList.remove("show");
}

function closeDetailModal() {
  document.getElementById("modal-detail").classList.remove("show");
}

// Request Creation & Client Validation
async function handleCreateSubmit(event) {
  event.preventDefault();

  const title = document.getElementById("form-title").value.trim();
  const desc = document.getElementById("form-desc").value.trim();
  const cat = document.getElementById("form-category").value;
  const urg = document.getElementById("form-urgency").value;
  const requester = document.getElementById("form-requester").value.trim();
  const contact = document.getElementById("form-contact").value.trim();
  const location = document.getElementById("form-location").value.trim();
  const deadline = document.getElementById("form-deadline").value;

  const payload = {
    title, description: desc, category: cat, urgency: urg,
    requester, contact, location,
    deadline: deadline || null
  };

  try {
    const res = await fetch("/api/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const json = await res.json();

    if (json.success) {
      showToast(`Request #${json.data.id} recorded successfully!`, "success");
      closeCreateModal();
      fetchStats();
      fetchRequests();

      if (json.duplicate_warnings && json.duplicate_warnings.length > 0) {
        showToast(`Note: ${json.duplicate_warnings.length} potential duplicate request(s) exist.`, "warning");
      }
    } else {
      const banner = document.getElementById("create-warning-banner");
      banner.innerText = `Validation Error: ${Array.isArray(json.errors) ? json.errors.join(", ") : json.error}`;
      banner.classList.remove("hidden");
    }
  } catch (err) {
    showToast("Network error submitting request.", "danger");
  }
}

// Quick Resolve Action
async function quickResolve(id) {
  const note = prompt("Enter resolution note (optional):", "Assistance provided and verified.");
  if (note === null) return; // User cancelled

  try {
    const res = await fetch(`/api/requests/${id}/resolve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ note })
    });
    const json = await res.json();
    if (json.success) {
      showToast(`Request #${id} marked as Resolved!`, "success");
      fetchStats();
      fetchRequests();
    } else {
      showToast(json.message || "Failed to resolve request.", "danger");
    }
  } catch (err) {
    showToast("Error updating status.", "danger");
  }
}

// Detailed Inspection Modal
async function inspectRequest(id) {
  try {
    const res = await fetch(`/api/requests/${id}`);
    const json = await res.json();
    if (json.success) {
      const req = json.data;
      document.getElementById("detail-modal-title").innerText = `Help Request #${req.id}`;
      document.getElementById("detail-modal-body").innerHTML = `
        <h4 style="font-size:1.15rem; color:#1e293b; margin-bottom:0.75rem;">${escapeHtml(req.title)}</h4>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:0.6rem; font-size:0.85rem; margin-bottom:1rem; background:#f8fafc; padding:0.75rem; border-radius:6px;">
          <div><strong>Category:</strong> ${escapeHtml(req.category)}</div>
          <div><strong>Urgency:</strong> <span class="badge badge-${req.urgency.toLowerCase()}">${escapeHtml(req.urgency)}</span></div>
          <div><strong>Status:</strong> <span class="badge badge-${req.status.toLowerCase().replace(' ','')}">${escapeHtml(req.status)}</span></div>
          <div><strong>Priority Score:</strong> <span style="font-weight:700; color:#7c3aed;">${req.priority_score.toFixed(1)}</span></div>
          <div><strong>Requester:</strong> ${escapeHtml(req.requester)}</div>
          <div><strong>Contact:</strong> ${escapeHtml(req.contact)}</div>
          <div><strong>Location:</strong> ${escapeHtml(req.location)}</div>
          <div><strong>Deadline:</strong> ${req.deadline || 'None'}</div>
          <div><strong>Created:</strong> ${req.created_at.replace('T', ' ').slice(0, 19)}</div>
          <div><strong>Updated:</strong> ${req.updated_at.replace('T', ' ').slice(0, 19)}</div>
        </div>
        <div>
          <strong style="font-size:0.85rem; color:#475569;">Detailed Description:</strong>
          <div style="margin-top:0.35rem; padding:0.75rem; background:#f1f5f9; border-radius:6px; font-size:0.9rem; white-space:pre-wrap;">${escapeHtml(req.description)}</div>
        </div>
      `;
      document.getElementById("modal-detail").classList.add("show");
    }
  } catch (e) {
    showToast("Failed to load details.", "danger");
  }
}

// Bulk CSV Submission
async function submitBulkCSV() {
  const content = document.getElementById("bulk-csv-input").value;
  if (!content.trim()) {
    showToast("Please provide CSV content to import.", "warning");
    return;
  }

  try {
    const res = await fetch("/api/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ csv_content: content })
    });
    const json = await res.json();
    if (json.success) {
      const box = document.getElementById("bulk-result-box");
      box.className = "alert-box alert-success mt-3";
      box.innerHTML = `<strong>Import Complete!</strong> Ingested <strong>${json.result.success_count}</strong> records. (Errors: ${json.result.failed_count})`;
      box.classList.remove("hidden");
      showToast(`Imported ${json.result.success_count} records.`, "success");
      fetchStats();
      fetchRequests();
    }
  } catch (e) {
    showToast("Bulk import failed.", "danger");
  }
}

function handleFileUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById("bulk-csv-input").value = e.target.result;
  };
  reader.readAsText(file);
}

// Triage View
async function renderTriageView() {
  try {
    const res = await fetch("/api/requests?order_by=priority_score%20DESC,%20id%20DESC&page_size=20");
    const json = await res.json();
    const container = document.getElementById("triage-items");
    container.innerHTML = "";

    if (json.success && json.data) {
      json.data.forEach((r, idx) => {
        const item = document.createElement("div");
        item.style.cssText = "display:flex; justify-content:space-between; align-items:center; padding:0.85rem 1rem; border-bottom:1px solid #e2e8f0;";
        item.innerHTML = `
          <div>
            <span style="font-weight:700; color:#64748b; margin-right:8px;">#${idx+1}</span>
            <strong style="color:#1e293b;">${escapeHtml(r.title)}</strong>
            <span style="font-size:0.78rem; color:#64748b; margin-left:8px;">(${escapeHtml(r.category)})</span>
          </div>
          <div style="display:flex; align-items:center; gap:12px;">
            <span class="badge badge-${r.urgency.toLowerCase()}">${escapeHtml(r.urgency)}</span>
            <span style="font-weight:700; font-size:1.1rem; color:#7c3aed;">${r.priority_score.toFixed(1)}</span>
          </div>
        `;
        container.appendChild(item);
      });
    }
  } catch (e) {}
}

// Warnings View
async function fetchWarnings() {
  try {
    const res = await fetch("/api/warnings");
    const json = await res.json();
    const container = document.getElementById("warnings-container");
    container.innerHTML = "";

    if (json.success) {
      const data = json.data;
      const sys = data.systemic_warnings || [];
      const rec = data.record_warnings || [];

      if (sys.length === 0 && rec.length === 0) {
        container.innerHTML = `<div class="alert-box alert-success">✓ Clean audit report: No logical anomalies or threshold violations detected.</div>`;
        return;
      }

      sys.forEach(w => {
        const div = document.createElement("div");
        div.className = "alert-box alert-warning mt-2";
        div.innerHTML = `<strong>[SYSTEMIC ${w.severity}] ${w.type}:</strong> ${w.message}`;
        container.appendChild(div);
      });

      rec.forEach(r => {
        const div = document.createElement("div");
        div.className = "alert-box alert-warning mt-2";
        div.innerHTML = `
          <strong>Request #${r.request_id} ('${escapeHtml(r.title)}') [${r.status}]:</strong>
          <ul style="margin-left:1.5rem; margin-top:0.35rem;">
            ${r.warnings.map(w => `<li><strong>${w.type} (${w.severity}):</strong> ${w.message}</li>`).join("")}
          </ul>
        `;
        container.appendChild(div);
      });
    }
  } catch (e) {}
}

// Dynamic SVG Chart Renderer
function renderSvgChart(containerId, data, color) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const keys = Object.keys(data);
  const values = Object.values(data);
  const maxVal = Math.max(...values, 1);

  if (keys.length === 0) {
    container.innerHTML = `<div class="text-muted text-center py-4">No data available.</div>`;
    return;
  }

  const barHeight = 26;
  const gap = 12;
  const width = 450;
  const height = keys.length * (barHeight + gap) + 30;
  const labelWidth = 140;
  const chartWidth = width - labelWidth - 50;

  let barsSvg = "";
  keys.forEach((key, i) => {
    const val = data[key];
    const y = i * (barHeight + gap) + 15;
    const barW = (val / maxVal) * chartWidth;

    barsSvg += `
      <text x="${labelWidth - 10}" y="${y + 17}" font-size="12" fill="#475569" text-anchor="end">${escapeHtml(key)}</text>
      <rect x="${labelWidth}" y="${y}" width="${Math.max(barW, 3)}" height="${barHeight}" fill="${color}" rx="4" />
      <text x="${labelWidth + barW + 8}" y="${y + 17}" font-size="12" font-weight="600" fill="#1e293b">${val}</text>
    `;
  });

  container.innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" style="width:100%; height:auto;">
      ${barsSvg}
    </svg>
  `;
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
