"""
Structured Logging and Observability Module
Provides enterprise-grade rotating file logs, console stream formatting,
and audit trail recording using Python standard logging.
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from typing import Optional, Any, Dict

# Ensure logs directory exists
LOG_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs"))
os.makedirs(LOG_DIR, exist_ok=True)
APP_LOG_PATH = os.path.join(LOG_DIR, "app.log")
AUDIT_LOG_PATH = os.path.join(LOG_DIR, "audit.log")

# Setup root logger
_logger: Optional[logging.Logger] = None
_audit_logger: Optional[logging.Logger] = None


def setup_logger(name: str = "StudentLifeHack", level: int = logging.INFO) -> logging.Logger:
    """Configures and returns the application logger with rotating file and console handlers."""
    global _logger
    if _logger is not None:
        return _logger

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)  # Capture all, handlers filter
    logger.propagate = False

    if not logger.handlers:
        # Standard structured formatter
        formatter = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s:%(funcName)s:%(lineno)d] - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )

        # Rotating File Handler (5 MB max, 3 backups)
        file_handler = RotatingFileHandler(
            APP_LOG_PATH, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        # Console Handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)  # Console shows warnings/errors by default
        console_formatter = logging.Formatter("[%(levelname)s] %(message)s")
        console_handler.setFormatter(console_formatter)
        logger.addHandler(console_handler)

    _logger = logger
    return _logger


def get_logger() -> logging.Logger:
    """Retrieves or initializes the application logger."""
    global _logger
    if _logger is None:
        return setup_logger()
    return _logger


def setup_audit_logger() -> logging.Logger:
    """Configures a dedicated immutable audit trail logger for state mutations."""
    global _audit_logger
    if _audit_logger is not None:
        return _audit_logger

    audit_logger = logging.getLogger("AuditTrail")
    audit_logger.setLevel(logging.INFO)
    audit_logger.propagate = False

    if not audit_logger.handlers:
        audit_formatter = logging.Formatter(
            fmt="%(asctime)s | AUDIT | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        audit_handler = RotatingFileHandler(
            AUDIT_LOG_PATH, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
        )
        audit_handler.setLevel(logging.INFO)
        audit_handler.setFormatter(audit_formatter)
        audit_logger.addHandler(audit_handler)

    _audit_logger = audit_logger
    return _audit_logger


def audit_log(action: str, entity_id: Any, details: Dict[str, Any], actor: str = "System/User") -> None:
    """
    Logs an immutable audit event for system security and lifecycle tracking.
    
    Args:
        action: Verb describing change (CREATE, UPDATE, DELETE, IMPORT, RESOLVE)
        entity_id: ID of the entity modified
        details: Dictionary of changed attributes or operational metadata
        actor: Identity of actor performing change
    """
    audit = setup_audit_logger()
    detail_str = " | ".join(f"{k}={v}" for k, v in details.items())
    audit.info(f"ACTION={action} | ID={entity_id} | ACTOR={actor} | {detail_str}")
    get_logger().debug(f"Audit record recorded for {action} on ID={entity_id}")
