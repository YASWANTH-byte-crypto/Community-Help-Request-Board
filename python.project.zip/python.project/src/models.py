"""
Domain Data Models
Defines immutable constraints, enums, and dataclass abstractions
representing Community Help Requests and operational states.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any
import json


class Category(str, Enum):
    ACADEMIC = "Academic"
    HEALTH_SAFETY = "Health & Safety"
    FOOD_ESSENTIALS = "Food & Essentials"
    TRANSPORTATION = "Transportation"
    HOUSING_UTILITIES = "Housing & Utilities"
    TECH_HARDWARE = "Technical & Hardware"
    MENTAL_HEALTH = "Mental Health"
    MISCELLANEOUS = "Miscellaneous"

    @classmethod
    def list_values(cls) -> List[str]:
        return [c.value for c in cls]


class Urgency(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

    @classmethod
    def list_values(cls) -> List[str]:
        return [u.value for u in cls]

    @property
    def weight(self) -> int:
        weights = {
            "Low": 1,
            "Medium": 2,
            "High": 3,
            "Critical": 4
        }
        return weights.get(self.value, 1)


class Status(str, Enum):
    OPEN = "Open"
    IN_PROGRESS = "In Progress"
    RESOLVED = "Resolved"
    CANCELLED = "Cancelled"

    @classmethod
    def list_values(cls) -> List[str]:
        return [s.value for s in cls]


@dataclass
class HelpRequest:
    """Represents a validated community help request record."""
    title: str
    description: str
    category: str
    urgency: str
    requester: str
    location: str
    contact: str
    id: Optional[int] = None
    status: str = Status.OPEN.value
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    deadline: Optional[str] = None  # Format: YYYY-MM-DD
    priority_score: float = 0.0
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Converts model to dictionary suitable for JSON serialization and DB storage."""
        data = asdict(self)
        if isinstance(data.get("tags"), list):
            data["tags_json"] = json.dumps(data["tags"])
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HelpRequest":
        """Instantiates a HelpRequest from raw dictionary with resilient type coercion."""
        tags = data.get("tags", [])
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except Exception:
                tags = [t.strip() for t in tags.split(",") if t.strip()]

        raw_id = data.get("id")
        req_id = int(raw_id) if raw_id is not None and str(raw_id).isdigit() else None

        return cls(
            id=req_id,
            title=str(data.get("title", "")).strip(),
            description=str(data.get("description", "")).strip(),
            category=str(data.get("category", Category.MISCELLANEOUS.value)).strip(),
            urgency=str(data.get("urgency", Urgency.MEDIUM.value)).strip(),
            status=str(data.get("status", Status.OPEN.value)).strip(),
            requester=str(data.get("requester", "")).strip(),
            location=str(data.get("location", "")).strip(),
            contact=str(data.get("contact", "")).strip(),
            created_at=str(data.get("created_at") or datetime.now(timezone.utc).isoformat()),
            updated_at=str(data.get("updated_at") or datetime.now(timezone.utc).isoformat()),
            deadline=str(data["deadline"]).strip() if data.get("deadline") else None,
            priority_score=float(data.get("priority_score", 0.0)),
            tags=tags if isinstance(tags, list) else []
        )

    def is_overdue(self) -> bool:
        """Determines if the request deadline has passed and is still unresolved."""
        if not self.deadline or self.status in [Status.RESOLVED.value, Status.CANCELLED.value]:
            return False
        try:
            deadline_date = datetime.strptime(self.deadline, "%Y-%m-%d").date()
            return deadline_date < datetime.now().date()
        except ValueError:
            return False

    def age_in_hours(self) -> float:
        """Calculates total hours elapsed since request creation."""
        try:
            # Handle ISO timestamp with or without Z/offset
            clean_ts = self.created_at.replace("Z", "+00:00")
            created_dt = datetime.fromisoformat(clean_ts)
            now_dt = datetime.now(timezone.utc)
            if created_dt.tzinfo is None:
                created_dt = created_dt.replace(tzinfo=timezone.utc)
            delta = now_dt - created_dt
            return max(0.0, delta.total_seconds() / 3600.0)
        except Exception:
            return 0.0
