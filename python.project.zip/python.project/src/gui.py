"""
Optional Desktop Graphical Interface (Tkinter)
Lightweight cross-platform GUI using standard library Tkinter.
Satisfies stretch feature 4.3: 'Optional lightweight Graphical Interface (Tkinter)'.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional

from src.logic import HelpRequestService
from src.models import Category, Urgency, Status


class HelpRequestGUI:
    """Tkinter-based desktop interface for Community Help Request Board."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("StudentLife Hack — Help Request Board (Desktop GUI)")
        self.root.geometry("900x600")
        self.root.minsize(700, 450)
        self.service = HelpRequestService()
        self._build_ui()
        self.refresh_list()

    def _build_ui(self):
        # Header frame
        header_frame = tk.Frame(self.root, bg="#1e293b", padx=15, pady=12)
        header_frame.pack(fill=tk.X)

        title_lbl = tk.Label(header_frame, text="Community Help Request Board", font=("Segoe UI", 14, "bold"), fg="#ffffff", bg="#1e293b")
        title_lbl.pack(side=tk.LEFT)

        subtitle_lbl = tk.Label(header_frame, text="Desktop GUI View", font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b")
        subtitle_lbl.pack(side=tk.LEFT, padx=10)

        # Action toolbar
        toolbar = tk.Frame(self.root, padx=10, pady=8, bg="#f1f5f9")
        toolbar.pack(fill=tk.X)

        tk.Button(toolbar, text="+ New Request", command=self.open_create_dialog, bg="#2563eb", fg="#ffffff", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=4)
        tk.Button(toolbar, text="✓ Quick Resolve", command=self.quick_resolve_selected, bg="#16a34a", fg="#ffffff").pack(side=tk.LEFT, padx=4)
        tk.Button(toolbar, text="🔄 Refresh", command=self.refresh_list).pack(side=tk.LEFT, padx=4)

        # Filter bar
        tk.Label(toolbar, text="Category:", bg="#f1f5f9").pack(side=tk.LEFT, padx=(15, 2))
        self.cat_var = tk.StringVar(value="All")
        cat_cb = ttk.Combobox(toolbar, textvariable=self.cat_var, values=["All"] + Category.list_values(), state="readonly", width=15)
        cat_cb.pack(side=tk.LEFT, padx=2)
        cat_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_list())

        # Main Table (Treeview)
        tree_frame = tk.Frame(self.root, padx=10, pady=5)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        columns = ("id", "priority", "urgency", "status", "category", "title", "requester", "deadline")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="ID")
        self.tree.heading("priority", text="Priority")
        self.tree.heading("urgency", text="Urgency")
        self.tree.heading("status", text="Status")
        self.tree.heading("category", text="Category")
        self.tree.heading("title", text="Title")
        self.tree.heading("requester", text="Requester")
        self.tree.heading("deadline", text="Deadline")

        self.tree.column("id", width=45, anchor=tk.CENTER)
        self.tree.column("priority", width=65, anchor=tk.CENTER)
        self.tree.column("urgency", width=75, anchor=tk.CENTER)
        self.tree.column("status", width=90, anchor=tk.CENTER)
        self.tree.column("category", width=130)
        self.tree.column("title", width=240)
        self.tree.column("requester", width=110)
        self.tree.column("deadline", width=85, anchor=tk.CENTER)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Status footer
        self.status_bar = tk.Label(self.root, text="Ready", bd=1, relief=tk.SUNKEN, anchor=tk.W, padx=8, pady=3, font=("Segoe UI", 8))
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def refresh_list(self):
        cat = self.cat_var.get()
        cat_filter = None if cat == "All" else cat

        for item in self.tree.get_children():
            self.tree.delete(item)

        items, total_count, _ = self.service.list_requests(category=cat_filter, page_size=200)
        for req in items:
            self.tree.insert("", tk.END, values=(
                req.id, f"{req.priority_score:.1f}", req.urgency, req.status,
                req.category, req.title, req.requester, req.deadline or "-"
            ))
        self.status_bar.config(text=f"Loaded {len(items)} requests (Total in DB: {total_count})")

    def quick_resolve_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select Record", "Please select a request from the table to resolve.")
            return

        item = self.tree.item(selected[0])
        req_id = int(item["values"][0])
        ok, msg = self.service.resolve_request(req_id, "Resolved via Desktop GUI")
        if ok:
            messagebox.showinfo("Success", f"Request #{req_id} has been marked as Resolved.")
            self.refresh_list()
        else:
            messagebox.showerror("Error", msg)

    def open_create_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Record New Help Request")
        dialog.geometry("450x450")
        dialog.transient(self.root)

        tk.Label(dialog, text="Title *").pack(anchor=tk.W, padx=15, pady=(10, 2))
        e_title = tk.Entry(dialog, width=45)
        e_title.pack(padx=15, fill=tk.X)

        tk.Label(dialog, text="Description *").pack(anchor=tk.W, padx=15, pady=(8, 2))
        e_desc = tk.Text(dialog, height=4, width=45)
        e_desc.pack(padx=15, fill=tk.X)

        tk.Label(dialog, text="Category *").pack(anchor=tk.W, padx=15, pady=(8, 2))
        e_cat = ttk.Combobox(dialog, values=Category.list_values(), state="readonly")
        e_cat.set(Category.ACADEMIC.value)
        e_cat.pack(padx=15, fill=tk.X)

        tk.Label(dialog, text="Urgency *").pack(anchor=tk.W, padx=15, pady=(8, 2))
        e_urg = ttk.Combobox(dialog, values=Urgency.list_values(), state="readonly")
        e_urg.set(Urgency.MEDIUM.value)
        e_urg.pack(padx=15, fill=tk.X)

        tk.Label(dialog, text="Requester Name *").pack(anchor=tk.W, padx=15, pady=(8, 2))
        e_req = tk.Entry(dialog, width=45)
        e_req.pack(padx=15, fill=tk.X)

        tk.Label(dialog, text="Contact Info (Email/Phone) *").pack(anchor=tk.W, padx=15, pady=(8, 2))
        e_con = tk.Entry(dialog, width=45)
        e_con.pack(padx=15, fill=tk.X)

        def save():
            payload = {
                "title": e_title.get(),
                "description": e_desc.get("1.0", tk.END).strip(),
                "category": e_cat.get(),
                "urgency": e_urg.get(),
                "requester": e_req.get(),
                "contact": e_con.get(),
                "location": "Campus Main"
            }
            ok, res, dups = self.service.create_request(payload)
            if ok:
                messagebox.showinfo("Success", f"Request #{res.id} created!")
                dialog.destroy()
                self.refresh_list()
            else:
                err_text = "\n".join(res) if isinstance(res, list) else str(res)
                messagebox.showerror("Validation Error", err_text)

        tk.Button(dialog, text="Save Request", command=save, bg="#2563eb", fg="#ffffff", pady=5).pack(pady=15)


def run_gui_app():
    root = tk.Tk()
    app = HelpRequestGUI(root)
    root.mainloop()


if __name__ == "__main__":
    run_gui_app()
