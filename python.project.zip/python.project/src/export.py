"""
Multi-Format Summary and Visual Export Module
Exports executive summaries and dataset records to:
- Structured Markdown (.md)
- Standardized CSV (.csv)
- Formatted JSON (.json)
- Plain-text Audit Log (.txt)
- Visual charts: Matplotlib PNG if installed, or vector SVG + ASCII fallback
"""

import os
import csv
import json
from datetime import datetime
from typing import Dict, Any, List

from src.models import HelpRequest
from src.logger import get_logger

REPORTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "reports"))
os.makedirs(REPORTS_DIR, exist_ok=True)


def export_markdown_report(stats: Dict[str, Any], warnings: Dict[str, Any], filepath: str = "") -> str:
    """Generates an executive-ready Markdown summary report."""
    if not filepath:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(REPORTS_DIR, f"executive_summary_{ts}.md")

    md = []
    md.append("# StudentLife Hack — Community Help Request Board")
    md.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    md.append(f"**Total Records:** {stats.get('total_records', 0)}")
    md.append(f"**Average Triage Priority Score:** {stats.get('average_priority', 0.0)}")
    md.append(f"**Overdue Requests:** {stats.get('overdue_count', 0)}\n")

    md.append("## 1. Status Breakdown")
    md.append("| Status | Count |")
    md.append("| :--- | :--- |")
    for status, count in stats.get("status_counts", {}).items():
        md.append(f"| {status} | {count} |")
    md.append("")

    md.append("## 2. Urgency Breakdown")
    md.append("| Urgency Level | Count |")
    md.append("| :--- | :--- |")
    for urg, count in stats.get("urgency_counts", {}).items():
        md.append(f"| {urg} | {count} |")
    md.append("")

    md.append("## 3. Category Distribution")
    md.append("| Category | Count |")
    md.append("| :--- | :--- |")
    for cat, count in stats.get("category_counts", {}).items():
        md.append(f"| {cat} | {count} |")
    md.append("")

    md.append("## 4. Anomalies & Warnings")
    rec_warnings = warnings.get("record_warnings", [])
    sys_warnings = warnings.get("systemic_warnings", [])

    if sys_warnings:
        md.append("### Systemic Distribution Warnings")
        for sw in sys_warnings:
            md.append(f"- **[{sw.get('severity')}] {sw.get('type')}:** {sw.get('message')}")
        md.append("")

    if rec_warnings:
        md.append("### Individual Record Anomalies")
        for rw in rec_warnings:
            md.append(f"- **Request #{rw.get('request_id')}** ('{rw.get('title')}'):")
            for w in rw.get("warnings", []):
                md.append(f"  - `[{w.get('severity')}]` {w.get('message')}")
    else:
        md.append("No record-level anomalies detected.")

    content = "\n".join(md)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)

    get_logger().info(f"Markdown summary report exported to {filepath}")
    return filepath


def export_csv_data(requests: List[HelpRequest], filepath: str = "") -> str:
    """Exports help request records to standardized CSV format."""
    if not filepath:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(REPORTS_DIR, f"requests_export_{ts}.csv")

    fieldnames = [
        "id", "title", "description", "category", "urgency", "status",
        "requester", "location", "contact", "created_at", "updated_at",
        "deadline", "priority_score", "tags"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for req in requests:
            d = req.to_dict()
            d["tags"] = ",".join(req.tags)
            d.pop("tags_json", None)
            writer.writerow({k: d.get(k, "") for k in fieldnames})

    get_logger().info(f"CSV exported to {filepath}")
    return filepath


def export_json_data(requests: List[HelpRequest], filepath: str = "") -> str:
    """Exports records to indented JSON."""
    if not filepath:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(REPORTS_DIR, f"requests_export_{ts}.json")

    data = [req.to_dict() for req in requests]
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    get_logger().info(f"JSON exported to {filepath}")
    return filepath


def generate_visual_charts(stats: Dict[str, Any], output_prefix: str = "chart") -> List[str]:
    """
    Attempts to generate PNG charts using Matplotlib.
    If Matplotlib is not installed, generates clean vector SVG charts instead,
    ensuring zero crash risk while demonstrating resilient system design.
    """
    generated_files: List[str] = []
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Try Matplotlib first
    try:
        import matplotlib
        matplotlib.use("Agg")  # Non-interactive headless backend
        import matplotlib.pyplot as plt

        # 1. Category Chart
        cat_data = stats.get("category_counts", {})
        if cat_data:
            plt.figure(figsize=(9, 5))
            cats = list(cat_data.keys())
            counts = list(cat_data.values())
            plt.bar(cats, counts, color="#3b82f6")
            plt.title("Requests by Category", fontsize=14, fontweight="bold")
            plt.xlabel("Category")
            plt.ylabel("Count")
            plt.xticks(rotation=30, ha="right")
            plt.tight_layout()
            cat_png = os.path.join(REPORTS_DIR, f"{output_prefix}_category_{ts}.png")
            plt.savefig(cat_png, dpi=150)
            plt.close()
            generated_files.append(cat_png)

        # 2. Urgency Chart
        urg_data = stats.get("urgency_counts", {})
        if urg_data:
            plt.figure(figsize=(7, 4.5))
            colors = ["#22c55e", "#eab308", "#f97316", "#ef4444"]
            plt.bar(list(urg_data.keys()), list(urg_data.values()), color=colors[:len(urg_data)])
            plt.title("Requests by Urgency Level", fontsize=14, fontweight="bold")
            plt.xlabel("Urgency")
            plt.ylabel("Count")
            plt.tight_layout()
            urg_png = os.path.join(REPORTS_DIR, f"{output_prefix}_urgency_{ts}.png")
            plt.savefig(urg_png, dpi=150)
            plt.close()
            generated_files.append(urg_png)

        return generated_files

    except ImportError:
        # Fallback to robust, standalone SVG vector chart generation
        cat_svg = _generate_svg_bar_chart(
            stats.get("category_counts", {}),
            "Community Help Requests by Category",
            os.path.join(REPORTS_DIR, f"{output_prefix}_category_{ts}.svg"),
            "#3b82f6"
        )
        urg_svg = _generate_svg_bar_chart(
            stats.get("urgency_counts", {}),
            "Community Help Requests by Urgency",
            os.path.join(REPORTS_DIR, f"{output_prefix}_urgency_{ts}.svg"),
            "#ef4444"
        )
        return [cat_svg, urg_svg]


def _generate_svg_bar_chart(data: Dict[str, int], title: str, filepath: str, bar_color: str) -> str:
    """Generates a crisp, dependency-free SVG bar chart."""
    width = 750
    height = 360
    margin_left = 160
    margin_bottom = 50
    margin_top = 60
    margin_right = 40

    chart_width = width - margin_left - margin_right
    chart_height = height - margin_top - margin_bottom

    keys = list(data.keys())
    values = [int(v) for v in data.values()]
    max_val = max(values) if values and max(values) > 0 else 1

    svg_parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" style="background:#ffffff; font-family:system-ui, sans-serif;">',
        f'<text x="{width / 2}" y="35" font-size="18" font-weight="bold" fill="#1e293b" text-anchor="middle">{title}</text>',
    ]

    n_bars = len(keys)
    if n_bars > 0:
        bar_height = min(28, (chart_height / n_bars) - 8)
        gap = (chart_height - (bar_height * n_bars)) / (n_bars + 1)

        for i, (k, v) in enumerate(zip(keys, values)):
            y = margin_top + gap + i * (bar_height + gap)
            bar_w = (v / max_val) * chart_width

            # Label
            svg_parts.append(
                f'<text x="{margin_left - 10}" y="{y + (bar_height / 2) + 4}" font-size="12" fill="#475569" text-anchor="end">{k}</text>'
            )
            # Bar
            svg_parts.append(
                f'<rect x="{margin_left}" y="{y}" width="{bar_w}" height="{bar_height}" fill="{bar_color}" rx="4"/>'
            )
            # Value
            svg_parts.append(
                f'<text x="{margin_left + bar_w + 8}" y="{y + (bar_height / 2) + 4}" font-size="12" font-weight="600" fill="#1e293b">{v}</text>'
            )

    svg_parts.append('</svg>')
    with open(filepath, "w", encoding="utf-8") as f:
        f.write("\n".join(svg_parts))

    return filepath


def render_ascii_bar_chart(data: Dict[str, int], title: str = "") -> str:
    """Renders a pure ASCII horizontal bar chart for terminal output."""
    lines = []
    if title:
        lines.append(f"\n--- {title} ---")
    if not data:
        lines.append("(No data available)")
        return "\n".join(lines)

    max_key_len = max(len(str(k)) for k in data.keys())
    max_val = max(data.values()) if data.values() and max(data.values()) > 0 else 1
    max_bar_width = 30

    for k, v in data.items():
        bar_len = int((v / max_val) * max_bar_width) if max_val > 0 else 0
        bar = "█" * bar_len
        lines.append(f"{str(k).rjust(max_key_len)} | {bar:<{max_bar_width}} ({v})")

    return "\n".join(lines)
