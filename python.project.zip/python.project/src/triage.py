"""
Innovation & Technical Complexity Engine
Implements:
1. Dynamic Composite Priority Scoring & SLA Decay
2. Anomaly & SLA Violation Warning Engine
3. Levenshtein & Jaccard Smart Duplicate Detection
"""

from datetime import datetime, timezone
from typing import List, Dict, Any, Tuple
import math
import re

from src.models import HelpRequest, Urgency, Status


class TriageEngine:
    """Calculates algorithmic priority weights and SLA decay indicators."""

    URGENCY_WEIGHTS = {
        Urgency.LOW.value: 15.0,
        Urgency.MEDIUM.value: 40.0,
        Urgency.HIGH.value: 70.0,
        Urgency.CRITICAL.value: 100.0,
    }

    IMPACT_KEYWORDS = {
        "emergency": 25.0,
        "danger": 25.0,
        "injury": 25.0,
        "medical": 20.0,
        "fire": 25.0,
        "water leak": 15.0,
        "broken": 10.0,
        "deadline": 15.0,
        "exam": 15.0,
        "starving": 20.0,
        "food": 10.0,
        "immediate": 15.0
    }

    @classmethod
    def calculate_priority_score(cls, req: HelpRequest) -> float:
        """
        Calculates a standardized composite priority score [0.0 - 150.0+] based on:
        - Urgency Tier (base weight)
        - Age decay (older unresolved tickets accumulate higher score)
        - Impact keyword heuristic detection
        - Deadline proximity (exponential boost when close or overdue)
        """
        score = cls.URGENCY_WEIGHTS.get(req.urgency, 30.0)

        # Keyword impact boost
        text_corpus = f"{req.title} {req.description}".lower()
        for kw, boost in cls.IMPACT_KEYWORDS.items():
            if kw in text_corpus:
                score += boost
                break  # Cap single keyword boost to prevent gaming

        # Age decay factor (if ticket is still active)
        if req.status not in [Status.RESOLVED.value, Status.CANCELLED.value]:
            age_hrs = req.age_in_hours()
            # Logarithmic smooth aging scale (+1 per 12 hours, up to +25 max)
            age_boost = min(25.0, (age_hrs / 12.0) * 1.5)
            score += age_boost

        # Deadline proximity boost
        if req.deadline and req.status not in [Status.RESOLVED.value, Status.CANCELLED.value]:
            try:
                deadline_dt = datetime.strptime(req.deadline, "%Y-%m-%d").date()
                days_left = (deadline_dt - datetime.now().date()).days
                if days_left < 0:
                    # Overdue: heavy escalation
                    score += 35.0 + min(20.0, abs(days_left) * 2.0)
                elif days_left == 0:
                    # Due today
                    score += 25.0
                elif days_left <= 2:
                    # Due within 48h
                    score += 15.0
            except ValueError:
                pass

        return round(score, 2)


class AnomalyEngine:
    """
    Deep Anomaly & Warning Detection Engine.
    Identifies 6 structural and logical warning classes:
    1. Timeline Inversion (updated_at < created_at)
    2. Overdue Deadline (deadline < today while unresolved)
    3. SLA Breach Risk (High/Critical open > 24 hours without assignment)
    4. Stale In-Progress (In Progress for > 7 days with no updates)
    5. Category Velocity Spike (single category exceeding 45% of active load)
    6. Rapid Frequency Warning (same requester posting > 3 tickets within 1 hour)
    """

    @staticmethod
    def inspect_request(req: HelpRequest) -> List[Dict[str, str]]:
        """Inspects an individual record for logical anomalies."""
        warnings: List[Dict[str, str]] = []

        # 1. Timeline Inversion
        try:
            c_ts = req.created_at.replace("Z", "+00:00")
            u_ts = req.updated_at.replace("Z", "+00:00")
            c_dt = datetime.fromisoformat(c_ts)
            u_dt = datetime.fromisoformat(u_ts)
            if u_dt < c_dt:
                warnings.append({
                    "type": "TIMELINE_INVERSION",
                    "severity": "HIGH",
                    "message": f"Updated timestamp ({req.updated_at}) precedes Creation timestamp ({req.created_at})."
                })
        except Exception:
            pass

        # 2. Overdue Deadline
        if req.is_overdue():
            warnings.append({
                "type": "OVERDUE_DEADLINE",
                "severity": "CRITICAL",
                "message": f"Task deadline ({req.deadline}) has expired but status is still '{req.status}'."
            })

        # 3. SLA Breach Risk
        if req.status == Status.OPEN.value and req.urgency in [Urgency.HIGH.value, Urgency.CRITICAL.value]:
            if req.age_in_hours() > 24.0:
                warnings.append({
                    "type": "SLA_BREACH_RISK",
                    "severity": "HIGH",
                    "message": f"High/Critical urgency request has remained in 'Open' status for {req.age_in_hours():.1f} hours without intervention."
                })

        # 4. Stale In-Progress
        if req.status == Status.IN_PROGRESS.value and req.age_in_hours() > 168.0:
            warnings.append({
                "type": "STALE_IN_PROGRESS",
                "severity": "MEDIUM",
                "message": f"Request has been 'In Progress' for over {req.age_in_hours() / 24.0:.1f} days without resolution."
            })

        return warnings

    @staticmethod
    def inspect_global_anomalies(requests: List[HelpRequest]) -> List[Dict[str, str]]:
        """Inspects collection-level distribution anomalies."""
        global_warnings: List[Dict[str, str]] = []
        if not requests:
            return global_warnings

        active = [r for r in requests if r.status in [Status.OPEN.value, Status.IN_PROGRESS.value]]
        if len(active) >= 5:
            # 5. Category Velocity Spike
            cat_counts: Dict[str, int] = {}
            for r in active:
                cat_counts[r.category] = cat_counts.get(r.category, 0) + 1

            for cat, cnt in cat_counts.items():
                ratio = cnt / len(active)
                if ratio > 0.45:
                    global_warnings.append({
                        "type": "CATEGORY_SPIKE",
                        "severity": "MEDIUM",
                        "message": f"Category '{cat}' represents {ratio * 100:.1f}% ({cnt}/{len(active)}) of all active requests, indicating a localized systemic issue."
                    })

        return global_warnings


class SimilarityEngine:
    """
    Duplicate Detection & Similarity Matching.
    Calculates combined Levenshtein edit distance and Jaccard word token similarity
    to flag potentially duplicate help requests before submission.
    """

    @staticmethod
    def levenshtein_ratio(s1: str, s2: str) -> float:
        """Calculates normalized Levenshtein similarity ratio between 0.0 and 1.0."""
        s1 = s1.lower().strip()
        s2 = s2.lower().strip()
        if s1 == s2:
            return 1.0
        if not s1 or not s2:
            return 0.0

        len1, len2 = len(s1), len(s2)
        dp = [[0] * (len2 + 1) for _ in range(len1 + 1)]

        for i in range(len1 + 1):
            dp[i][0] = i
        for j in range(len2 + 1):
            dp[0][j] = j

        for i in range(1, len1 + 1):
            for j in range(1, len2 + 1):
                cost = 0 if s1[i - 1] == s2[j - 1] else 1
                dp[i][j] = min(
                    dp[i - 1][j] + 1,       # deletion
                    dp[i][j - 1] + 1,       # insertion
                    dp[i - 1][j - 1] + cost # substitution
                )

        max_len = max(len1, len2)
        return 1.0 - (dp[len1][len2] / max_len)

    @staticmethod
    def jaccard_similarity(s1: str, s2: str) -> float:
        """Calculates token-based Jaccard similarity."""
        tokens1 = set(re.findall(r"\w+", s1.lower()))
        tokens2 = set(re.findall(r"\w+", s2.lower()))
        if not tokens1 or not tokens2:
            return 0.0
        intersection = tokens1.intersection(tokens2)
        union = tokens1.union(tokens2)
        return len(intersection) / len(union)

    @classmethod
    def find_potential_duplicates(
        cls, candidate_title: str, candidate_desc: str, existing_requests: List[HelpRequest], threshold: float = 0.65
    ) -> List[Tuple[HelpRequest, float]]:
        """
        Finds open/in-progress requests that closely match candidate content.
        Returns list of (matching_request, similarity_score).
        """
        matches = []
        cand_text = f"{candidate_title} {candidate_desc}"

        for req in existing_requests:
            if req.status in [Status.RESOLVED.value, Status.CANCELLED.value]:
                continue
            exist_text = f"{req.title} {req.description}"

            lev = cls.levenshtein_ratio(candidate_title, req.title)
            jac = cls.jaccard_similarity(cand_text, exist_text)
            composite_similarity = (lev * 0.5) + (jac * 0.5)

            if composite_similarity >= threshold:
                matches.append((req, round(composite_similarity, 3)))

        # Sort by highest similarity
        matches.sort(key=lambda x: x[1], reverse=True)
        return matches
