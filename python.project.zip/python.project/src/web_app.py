"""
Embedded High-Performance Web Dashboard and REST API Server
Built on Python standard library http.server — requires zero external npm/pip dependencies.
Serves the modern frontend and handles full RESTful JSON operations.
"""

import os
import json
import mimetypes
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Any

from src.logic import HelpRequestService
from src.logger import get_logger
from src.external_sync import ExternalServiceSync
from src.export import export_markdown_report, export_csv_data, export_json_data

STATIC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "static"))


class CommunityHelpApiHandler(BaseHTTPRequestHandler):
    """Handles RESTful API endpoints and serves static UI assets."""

    service = HelpRequestService()

    def log_message(self, format, *args):
        # Route server logs through standard logger
        get_logger().debug(f"HTTP Server: {self.client_address[0]} - {format % args}")

    def _send_json(self, data: Any, status: int = 200) -> None:
        """Sends JSON encoded response with CORS headers."""
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, file_path: str, content_type: str = "text/plain") -> None:
        """Serves a static file from disk."""
        if not os.path.exists(file_path):
            self.send_error(404, "File Not Found")
            return
        with open(file_path, "rb") as f:
            content = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_OPTIONS(self):
        """Handles CORS pre-flight requests."""
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        # 1. Static Web Frontend Routes
        if path == "/" or path == "/index.html":
            index_path = os.path.join(STATIC_DIR, "index.html")
            return self._send_file(index_path, "text/html; charset=utf-8")

        if path.startswith("/static/"):
            rel_path = path[len("/static/"):].lstrip("/\\")
            full_path = os.path.abspath(os.path.join(STATIC_DIR, rel_path))
            # Prevent directory traversal
            if not full_path.startswith(STATIC_DIR):
                return self.send_error(403, "Forbidden")
            mime, _ = mimetypes.guess_type(full_path)
            return self._send_file(full_path, mime or "application/octet-stream")

        # 2. REST API Routes
        if path == "/api/stats":
            stats = self.service.get_executive_summary()
            return self._send_json({"success": True, "data": stats})

        if path == "/api/warnings":
            warnings = self.service.get_warnings_and_anomalies()
            return self._send_json({"success": True, "data": warnings})

        if path == "/api/alerts":
            alerts = ExternalServiceSync.fetch_campus_alerts()
            return self._send_json({"success": True, "data": alerts})

        if path == "/api/requests":
            cat = query.get("category", [None])[0]
            urg = query.get("urgency", [None])[0]
            stat = query.get("status", [None])[0]
            kw = query.get("keyword", [None])[0]
            order = query.get("order_by", ["priority_score DESC, id DESC"])[0]
            page = int(query.get("page", [1])[0])
            size = int(query.get("page_size", [10])[0])

            items, total_count, total_pages = self.service.list_requests(
                category=cat, urgency=urg, status=stat, keyword=kw,
                order_by=order, page=page, page_size=size
            )
            return self._send_json({
                "success": True,
                "data": [req.to_dict() for req in items],
                "meta": {
                    "page": page,
                    "page_size": size,
                    "total_records": total_count,
                    "total_pages": total_pages
                }
            })

        if path.startswith("/api/requests/"):
            raw_id = path.split("/")[-1]
            if raw_id.isdigit():
                req = self.service.db.get_by_id(int(raw_id))
                if req:
                    return self._send_json({"success": True, "data": req.to_dict()})
                return self._send_json({"success": False, "error": "Request not found"}, status=404)

        if path.startswith("/api/export/"):
            fmt = path.split("/")[-1].lower()
            stats = self.service.get_executive_summary()
            warns = self.service.get_warnings_and_anomalies()
            reqs, _ = self.service.db.get_all(limit=1000)

            if fmt == "markdown":
                fpath = export_markdown_report(stats, warns)
                return self._send_file(fpath, "text/markdown; charset=utf-8")
            elif fmt == "csv":
                fpath = export_csv_data(reqs)
                return self._send_file(fpath, "text/csv; charset=utf-8")
            elif fmt == "json":
                fpath = export_json_data(reqs)
                return self._send_file(fpath, "application/json; charset=utf-8")
            else:
                return self._send_json({"success": False, "error": "Unsupported export format"}, status=400)

        self.send_error(404, "Not Found")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # Read JSON body
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else ""

        # Endpoint: Create Request
        if path == "/api/requests":
            try:
                payload = json.loads(body) if body else {}
            except json.JSONDecodeError:
                return self._send_json({"success": False, "error": "Invalid JSON format"}, status=400)

            success, result, duplicates = self.service.create_request(payload)
            if success:
                return self._send_json({
                    "success": True,
                    "data": result.to_dict(),
                    "duplicate_warnings": duplicates
                }, status=201)
            else:
                return self._send_json({"success": False, "errors": result}, status=400)

        # Endpoint: Quick Resolve
        if path.startswith("/api/requests/") and path.endswith("/resolve"):
            parts = path.split("/")
            raw_id = parts[3]
            if raw_id.isdigit():
                note = ""
                try:
                    payload = json.loads(body) if body else {}
                    note = payload.get("note", "")
                except Exception:
                    pass
                success, msg = self.service.resolve_request(int(raw_id), note)
                return self._send_json({"success": success, "message": msg}, status=200 if success else 400)

        # Endpoint: Bulk CSV Import
        if path == "/api/import":
            try:
                payload = json.loads(body) if body else {}
                csv_data = payload.get("csv_content", "")
            except Exception:
                csv_data = body

            if not csv_data.strip():
                return self._send_json({"success": False, "error": "Empty CSV content"}, status=400)

            result = self.service.import_csv_dataset(csv_data)
            return self._send_json({"success": True, "result": result})

        self.send_error(404, "Not Found")

    def do_PUT(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/requests/"):
            raw_id = path.split("/")[-1]
            if raw_id.isdigit():
                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else ""
                try:
                    payload = json.loads(body) if body else {}
                except json.JSONDecodeError:
                    return self._send_json({"success": False, "error": "Invalid JSON format"}, status=400)

                success, result = self.service.update_request(int(raw_id), payload)
                if success:
                    return self._send_json({"success": True, "data": result.to_dict()})
                else:
                    return self._send_json({"success": False, "errors": result}, status=400)

        self.send_error(404, "Not Found")

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/requests/"):
            raw_id = path.split("/")[-1]
            if raw_id.isdigit():
                deleted = self.service.db.delete(int(raw_id))
                if deleted:
                    return self._send_json({"success": True, "message": f"Request #{raw_id} deleted."})
                return self._send_json({"success": False, "error": "Request not found."}, status=404)

        self.send_error(404, "Not Found")


def run_web_server(host: str = "127.0.0.1", port: int = 8000) -> None:
    """Launches the embedded HTTP Web Dashboard server."""
    server_address = (host, port)
    httpd = HTTPServer(server_address, CommunityHelpApiHandler)
    logger = get_logger()
    logger.info(f"Interactive Web Dashboard running at http://{host}:{port}/")
    print("\n" + "=" * 70)
    print(f"🚀 Community Help Request Board Web Dashboard is LIVE!")
    print(f"🌐 Access URL: http://{host}:{port}/")
    print(f"📂 Serving modern responsive frontend from: {STATIC_DIR}")
    print("   Press Ctrl+C to terminate.")
    print("=" * 70 + "\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down web server...")
        httpd.server_close()
