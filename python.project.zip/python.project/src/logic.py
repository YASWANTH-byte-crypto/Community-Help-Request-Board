"""
Core Business Logic Service Layer
Coordinates database operations, defensive validation, triage calculation,
anomaly checking, and bulk dataset processing.
"""

import csv
import io
import json
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple

from src.models import HelpRequest, Status, Category, Urgency
from src.database import DatabaseManager, DEFAULT_DB_PATH
from src.validation import validate_request_payload, sanitize_string
from src.triage import TriageEngine, AnomalyEngine, SimilarityEngine
from src.logger import get_logger, audit_log


class HelpRequestService:
    """Enterprise service layer handling domain transactions and business workflows."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.db = db_manager or DatabaseManager()
        self.logger = get_logger()

    def create_request(self, payload: Dict[str, Any], check_duplicates: bool = True) -> Tuple[bool, Any, List[Dict[str, Any]]]:
        """
        Validates, scores, detects duplicates, and persists a new HelpRequest.
        Returns (success, HelpRequest or error_list, duplicate_warnings).
        """
        is_valid, sanitized, errors = validate_request_payload(payload)
        if not is_valid:
            self.logger.warning(f"Request creation failed validation: {errors}")
            return False, errors, []

        # Check duplicates if enabled
        duplicate_warnings = []
        if check_duplicates:
            existing_active, _ = self.db.get_all(limit=100)
            duplicates = SimilarityEngine.find_potential_duplicates(
                sanitized["title"], sanitized["description"], existing_active
            )
            for dup_req, sim_score in duplicates:
                duplicate_warnings.append({
                    "id": dup_req.id,
                    "title": dup_req.title,
                    "similarity": sim_score,
                    "status": dup_req.status
                })

        req = HelpRequest.from_dict(sanitized)
        # Compute algorithmic priority score
        req.priority_score = TriageEngine.calculate_priority_score(req)

        saved = self.db.create(req)
        return True, saved, duplicate_warnings

    def update_request(self, req_id: int, updates: Dict[str, Any]) -> Tuple[bool, Any]:
        """Updates request fields with strict validation."""
        existing = self.db.get_by_id(req_id)
        if not existing:
            return False, f"Help request ID {req_id} not found."

        merged = existing.to_dict()
        merged.update(updates)
        merged["id"] = req_id

        is_valid, sanitized, errors = validate_request_payload(merged)
        if not is_valid:
            return False, errors

        updated_req = HelpRequest.from_dict(sanitized)
        # Recompute priority score upon update
        updated_req.priority_score = TriageEngine.calculate_priority_score(updated_req)

        success = self.db.update(updated_req)
        return success, updated_req

    def resolve_request(self, req_id: int, note: Optional[str] = None) -> Tuple[bool, str]:
        """Transitions request to Resolved status."""
        existing = self.db.get_by_id(req_id)
        if not existing:
            return False, f"Request #{req_id} not found."

        existing.status = Status.RESOLVED.value
        existing.priority_score = 0.0  # Resolved items zero out priority
        if note:
            existing.description += f"\n[Resolution Note: {sanitize_string(note)}]"

        success = self.db.update(existing)
        if success:
            audit_log("RESOLVE", req_id, {"note": note or ""})
            return True, f"Request #{req_id} marked as Resolved."
        return False, "Failed to update record in database."

    def list_requests(
        self,
        category: Optional[str] = None,
        urgency: Optional[str] = None,
        status: Optional[str] = None,
        keyword: Optional[str] = None,
        order_by: str = "priority_score DESC, id DESC",
        page: int = 1,
        page_size: int = 10
    ) -> Tuple[List[HelpRequest], int, int]:
        """
        Returns paginated requests, total record count, and total page count.
        """
        page = max(1, page)
        offset = (page - 1) * page_size
        items, total_count = self.db.get_all(
            category=category,
            urgency=urgency,
            status=status,
            keyword=keyword,
            order_by=order_by,
            limit=page_size,
            offset=offset
        )
        total_pages = (total_count + page_size - 1) // page_size if total_count > 0 else 1
        return items, total_count, total_pages

    def get_warnings_and_anomalies(self) -> Dict[str, Any]:
        """Aggregates all individual and systemic operational warnings."""
        all_reqs, _ = self.db.get_all(limit=1000)
        item_warnings = []
        for req in all_reqs:
            w_list = AnomalyEngine.inspect_request(req)
            if w_list:
                item_warnings.append({
                    "request_id": req.id,
                    "title": req.title,
                    "status": req.status,
                    "warnings": w_list
                })

        systemic_warnings = AnomalyEngine.inspect_global_anomalies(all_reqs)

        return {
            "total_flagged_records": len(item_warnings),
            "record_warnings": item_warnings,
            "systemic_warnings": systemic_warnings
        }

    def import_csv_dataset(self, csv_content: str) -> Dict[str, Any]:
        """
        Bulk dataset ingestion with automatic schema detection and row-by-row error logs.
        """
        reader = csv.DictReader(io.StringIO(csv_content))
        success_count = 0
        failed_rows = []
        to_insert: List[HelpRequest] = []

        for idx, row in enumerate(reader, start=2):  # start=2 considering header line 1
            is_valid, sanitized, errors = validate_request_payload(row)
            if is_valid:
                req = HelpRequest.from_dict(sanitized)
                req.priority_score = TriageEngine.calculate_priority_score(req)
                to_insert.append(req)
                success_count += 1
            else:
                failed_rows.append({
                    "row_number": idx,
                    "row_data": row,
                    "errors": errors
                })

        if to_insert:
            self.db.bulk_insert(to_insert)

        self.logger.info(f"Bulk CSV import completed: {success_count} inserted, {len(failed_rows)} errors.")
        return {
            "success_count": success_count,
            "failed_count": len(failed_rows),
            "errors": failed_rows
        }

    def get_executive_summary(self) -> Dict[str, Any]:
        """Generates comprehensive aggregated metrics for reporting."""
        stats = self.db.get_summary_stats()
        warnings = self.get_warnings_and_anomalies()
        stats["active_warnings_count"] = warnings["total_flagged_records"] + len(warnings["systemic_warnings"])
        return stats
