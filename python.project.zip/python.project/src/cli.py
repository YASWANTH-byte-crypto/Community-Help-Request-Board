"""
Interactive Terminal Interface (CLI)
Feature-complete menu-driven command prompt facilitating seamless user interactions,
defensive validation with 'cancel' support, tabular displays with pagination,
keyword & category queries, executive analytics, and multi-format reports.
"""

import sys
import os
from typing import Optional, List, Dict, Any

from src.models import HelpRequest, Category, Urgency, Status
from src.logic import HelpRequestService
from src.validation import (
    validate_title, validate_description, validate_category,
    validate_urgency, validate_status, validate_contact,
    validate_deadline, is_cancel_token
)
from src.export import (
    export_markdown_report, export_csv_data, export_json_data,
    generate_visual_charts, render_ascii_bar_chart
)
from src.external_sync import ExternalServiceSync


class TerminalCLI:
    """Production CLI navigation dispatch and interaction controller."""

    def __init__(self, service: Optional[HelpRequestService] = None):
        self.service = service or HelpRequestService()

    def print_banner(self) -> None:
        """Displays branded welcome header."""
        banner = r"""
================================================================================
   ____ _             _            _   _     _  __      _   _            _    
  / ___| |_ _   _  __| | ___ _ __ | |_| |   (_)/ _| ___| | | | __ _  ___| | __
  \___ \ __| | | |/ _` |/ _ \ '_ \| __| |   | | |_ / _ \ |_| |/ _` |/ __| |/ /
   ___) | |_| |_| | (_| |  __/ | | | |_| |___| |  _|  __/  _  | (_| | (__|   < 
  |____/ \__|\__,_|\__,_|\___|_| |_|\__|_____|_|_|  \___|_| |_|\__,_|\___|_|\_\
          Community Help Request Board — Enterprise Edition v2.0
================================================================================
"""
        print(banner)

    def prompt_input(self, prompt_text: str, validator_fn=None, default: Optional[str] = None) -> Optional[str]:
        """
        Interactive prompt wrapper that enforces validation and supports 'cancel' at any stage.
        Loops defensively until valid entry is provided or user cancels.
        """
        while True:
            suffix = f" [{default}]" if default else ""
            try:
                user_val = input(f"{prompt_text}{suffix} (or 'cancel'): ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\n[Operation Aborted by User]")
                return None

            if is_cancel_token(user_val):
                print("[Action Cancelled]")
                return None

            if not user_val and default is not None:
                user_val = default

            if validator_fn is None:
                return user_val

            ok, clean_or_err = validator_fn(user_val)
            if ok:
                return clean_or_err
            else:
                print(f"  [Validation Error]: {clean_or_err}. Please try again.")

    def run(self) -> None:
        """Main navigation dispatch loop."""
        self.print_banner()
        while True:
            print("\n" + "=" * 60)
            print("MAIN MENU:")
            print("  1. Record New Help Request (with defensive validation & duplicate check)")
            print("  2. View / Search Help Requests (with filters & pagination)")
            print("  3. Update Request Status or Details")
            print("  4. Quick Resolve Request")
            print("  5. Executive Analytics & ASCII Visualizations")
            print("  6. Threshold Warnings & Anomaly Inspector")
            print("  7. Multi-Format Summary Export (Markdown, CSV, JSON, Charts)")
            print("  8. Bulk CSV Dataset Ingestion")
            print("  9. External Campus Alerts & Weather Feed")
            print("  0. Exit")
            print("=" * 60)

            choice = input("Select an option (0-9): ").strip()
            if choice == "1":
                self.handle_create_request()
            elif choice == "2":
                self.handle_list_requests()
            elif choice == "3":
                self.handle_update_request()
            elif choice == "4":
                self.handle_resolve_request()
            elif choice == "5":
                self.handle_analytics()
            elif choice == "6":
                self.handle_warnings()
            elif choice == "7":
                self.handle_export()
            elif choice == "8":
                self.handle_bulk_import()
            elif choice == "9":
                self.handle_external_feed()
            elif choice in ["0", "exit", "quit", ":q"]:
                print("\nThank you for using Community Help Request Board. Goodbye!\n")
                break
            else:
                print("Invalid selection. Please choose an option from 0 to 9.")

    def handle_create_request(self) -> None:
        """Guides user through defensive creation workflow."""
        print("\n--- RECORD NEW HELP REQUEST ---")
        print("(Enter 'cancel' at any prompt to abort)\n")

        title = self.prompt_input("Title", validate_title)
        if title is None:
            return

        desc = self.prompt_input("Description", validate_description)
        if desc is None:
            return

        print(f"Categories: {', '.join(Category.list_values())}")
        category = self.prompt_input("Category", validate_category, default=Category.MISCELLANEOUS.value)
        if category is None:
            return

        print(f"Urgency Levels: {', '.join(Urgency.list_values())}")
        urgency = self.prompt_input("Urgency", validate_urgency, default=Urgency.MEDIUM.value)
        if urgency is None:
            return

        requester = self.prompt_input("Requester Name / Student ID", lambda s: (bool(s.strip()), "Name required"))
        if requester is None:
            return

        location = self.prompt_input("Location / Dorm / Lab", lambda s: (bool(s.strip()), "Location required"))
        if location is None:
            return

        contact = self.prompt_input("Contact (Email / Phone / @Handle)", validate_contact)
        if contact is None:
            return

        deadline = self.prompt_input("Deadline [YYYY-MM-DD] (optional)", validate_deadline, default="")
        if deadline is None:
            return

        payload = {
            "title": title,
            "description": desc,
            "category": category,
            "urgency": urgency,
            "requester": requester,
            "location": location,
            "contact": contact,
            "deadline": deadline if deadline else None
        }

        success, result, duplicates = self.service.create_request(payload)
        if not success:
            print(f"\n[ERROR] Failed to save request: {result}")
            return

        print(f"\n[SUCCESS] Help Request #{result.id} successfully recorded!")
        print(f"  Calculated Priority Score: {result.priority_score:.1f}")

        if duplicates:
            print(f"\n[ALERT] {len(duplicates)} Potential Duplicate Request(s) Detected:")
            for dup in duplicates:
                print(f"  - Match with #{dup['id']} ('{dup['title']}') | Similarity: {dup['similarity']*100:.1f}%")

    def handle_list_requests(self) -> None:
        """Displays filtered requests with pagination."""
        print("\n--- VIEW / SEARCH HELP REQUESTS ---")
        print("Optional search & filter criteria (press Enter to skip):")

        cat_filter = input(f"Filter by Category ({', '.join(Category.list_values())}): ").strip() or None
        urg_filter = input(f"Filter by Urgency ({', '.join(Urgency.list_values())}): ").strip() or None
        stat_filter = input(f"Filter by Status ({', '.join(Status.list_values())}): ").strip() or None
        keyword = input("Search keyword (title, desc, requester, loc): ").strip() or None

        page = 1
        page_size = 5

        while True:
            items, total_count, total_pages = self.service.list_requests(
                category=cat_filter,
                urgency=urg_filter,
                status=stat_filter,
                keyword=keyword,
                page=page,
                page_size=page_size
            )

            print(f"\nShowing Page {page} of {total_pages} (Total Records Found: {total_count})")
            print("-" * 90)
            print(f"{'ID':<4} | {'Priority':<8} | {'Urgency':<8} | {'Status':<12} | {'Category':<18} | {'Title'}")
            print("-" * 90)

            if not items:
                print("No requests matched the specified filters.")
            else:
                for req in items:
                    urg_tag = req.urgency
                    stat_tag = req.status
                    print(f"{req.id:<4} | {req.priority_score:<8.1f} | {urg_tag:<8} | {stat_tag:<12} | {req.category[:18]:<18} | {req.title[:30]}")

            print("-" * 90)
            nav = input("[N]ext Page | [P]revious Page | [V]iew Details by ID | [E]xit List: ").strip().lower()
            if nav == "n":
                if page < total_pages:
                    page += 1
                else:
                    print("Already on the last page.")
            elif nav == "p":
                if page > 1:
                    page -= 1
                else:
                    print("Already on the first page.")
            elif nav == "v":
                raw_id = input("Enter Request ID to inspect: ").strip()
                if raw_id.isdigit():
                    req_obj = self.service.db.get_by_id(int(raw_id))
                    if req_obj:
                        self._print_request_details(req_obj)
                    else:
                        print(f"Request #{raw_id} not found.")
            elif nav in ["e", "cancel", "q", ""]:
                break

    def _print_request_details(self, req: HelpRequest) -> None:
        """Prints detailed inspector card for a request."""
        print("\n" + "=" * 60)
        print(f"REQUEST DETAILS: #{req.id} - {req.title}")
        print("=" * 60)
        print(f"  Category:       {req.category}")
        print(f"  Urgency:        {req.urgency}")
        print(f"  Status:         {req.status}")
        print(f"  Priority Score: {req.priority_score:.1f}")
        print(f"  Requester:      {req.requester} ({req.contact})")
        print(f"  Location:       {req.location}")
        print(f"  Created At:     {req.created_at}")
        print(f"  Updated At:     {req.updated_at}")
        print(f"  Deadline:       {req.deadline or 'None'}")
        print(f"  Is Overdue:     {'YES (EXPIRED)' if req.is_overdue() else 'No'}")
        print(f"  Description:\n    {req.description}")
        print("=" * 60)

    def handle_update_request(self) -> None:
        """Handles modifying request fields."""
        print("\n--- UPDATE REQUEST DETAILS ---")
        raw_id = self.prompt_input("Enter Request ID to update")
        if not raw_id or not raw_id.isdigit():
            return

        req = self.service.db.get_by_id(int(raw_id))
        if not req:
            print(f"Request #{raw_id} not found.")
            return

        self._print_request_details(req)
        print("\nEnter new values (press Enter to keep current):")

        new_status = self.prompt_input(f"Status ({', '.join(Status.list_values())})", default=req.status)
        new_urg = self.prompt_input(f"Urgency ({', '.join(Urgency.list_values())})", default=req.urgency)
        new_loc = self.prompt_input("Location", default=req.location)

        updates = {
            "status": new_status,
            "urgency": new_urg,
            "location": new_loc
        }

        ok, res = self.service.update_request(req.id, updates)
        if ok:
            print(f"\n[SUCCESS] Request #{req.id} successfully updated!")
        else:
            print(f"\n[ERROR] Update failed: {res}")

    def handle_resolve_request(self) -> None:
        """Fast-track resolution action."""
        print("\n--- QUICK RESOLVE REQUEST ---")
        raw_id = self.prompt_input("Enter Request ID to mark as Resolved")
        if not raw_id or not raw_id.isdigit():
            return

        note = self.prompt_input("Resolution note (optional)", default="")
        ok, msg = self.service.resolve_request(int(raw_id), note)
        print(f"\n{'[SUCCESS]' if ok else '[ERROR]'} {msg}")

    def handle_analytics(self) -> None:
        """Displays executive aggregate metrics with ASCII graphs."""
        print("\n--- EXECUTIVE ANALYTICS DASHBOARD ---")
        stats = self.service.get_executive_summary()

        print(f"Total Requests:       {stats.get('total_records', 0)}")
        print(f"Average Priority:     {stats.get('average_priority', 0.0)}")
        print(f"Overdue Requests:     {stats.get('overdue_count', 0)}")
        print(f"Active Warnings:      {stats.get('active_warnings_count', 0)}")

        print(render_ascii_bar_chart(stats.get("urgency_counts", {}), "Urgency Distribution"))
        print(render_ascii_bar_chart(stats.get("status_counts", {}), "Status Overview"))
        print(render_ascii_bar_chart(stats.get("category_counts", {}), "Category Breakdown"))

    def handle_warnings(self) -> None:
        """Runs anomaly and threshold detector."""
        print("\n--- THRESHOLD WARNINGS & ANOMALY INSPECTOR ---")
        data = self.service.get_warnings_and_anomalies()

        sys_w = data.get("systemic_warnings", [])
        rec_w = data.get("record_warnings", [])

        if sys_w:
            print("\n[!] SYSTEMIC DISTRIBUTION WARNINGS:")
            for w in sys_w:
                print(f"  - [{w['severity']}] {w['type']}: {w['message']}")

        if rec_w:
            print(f"\n[!] INDIVIDUAL RECORD ANOMALIES ({len(rec_w)} flagged):")
            for rw in rec_w:
                print(f"\n  Request #{rw['request_id']} — '{rw['title']}' ({rw['status']}):")
                for w in rw['warnings']:
                    print(f"    * [{w['severity']}] {w['message']}")
        else:
            print("\n[OK] No individual record anomalies detected.")

    def handle_export(self) -> None:
        """Generates multi-format summary reports."""
        print("\n--- MULTI-FORMAT SUMMARY EXPORT ---")
        stats = self.service.get_executive_summary()
        warnings = self.service.get_warnings_and_anomalies()
        all_reqs, _ = self.service.db.get_all(limit=1000)

        # 1. Markdown
        md_file = export_markdown_report(stats, warnings)
        print(f" [✓] Markdown Report:   {md_file}")

        # 2. CSV
        csv_file = export_csv_data(all_reqs)
        print(f" [✓] Standard CSV Data: {csv_file}")

        # 3. JSON
        json_file = export_json_data(all_reqs)
        print(f" [✓] Formatted JSON:    {json_file}")

        # 4. Charts
        chart_files = generate_visual_charts(stats)
        for cf in chart_files:
            print(f" [✓] Visual Chart:      {cf}")

        print("\nAll export artifacts successfully generated in the 'reports/' directory!")

    def handle_bulk_import(self) -> None:
        """Imports CSV file with detailed row-by-row error logs."""
        print("\n--- BULK CSV DATASET INGESTION ---")
        path = self.prompt_input("Enter path to CSV file")
        if not path:
            return

        if not os.path.exists(path):
            print(f"[ERROR] File not found at '{path}'.")
            return

        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            results = self.service.import_csv_dataset(content)
            print(f"\n[IMPORT RESULT] Successfully imported: {results['success_count']} records.")
            if results["failed_count"] > 0:
                print(f"[WARNING] {results['failed_count']} rows failed validation:")
                for err in results["errors"][:5]:  # show top 5
                    print(f"  Row {err['row_number']}: {', '.join(err['errors'])}")
        except Exception as e:
            print(f"[ERROR] Failed to read or parse file: {e}")

    def handle_external_feed(self) -> None:
        """Displays external campus feed."""
        print("\n--- EXTERNAL CAMPUS ALERTS FEED ---")
        res = ExternalServiceSync.fetch_campus_alerts()
        print(f"Source: {res['source']}")
        feed = res.get("data", {})
        print(f"Status: {feed.get('status')} | Last Sync: {feed.get('last_sync')}")
        print("\nCampus Announcements:")
        for ann in feed.get("campus_announcements", []):
            print(f"  [{ann.get('level')}] {ann.get('title')}")
        print("\nEmergency Contacts:")
        for k, v in feed.get("emergency_contacts", {}).items():
            print(f"  {k.replace('_', ' ').title()}: {v}")
