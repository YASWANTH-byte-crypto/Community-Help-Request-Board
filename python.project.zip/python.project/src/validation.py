"""
Defensive Input Validation Engine
Implements strict real-time sanitization, regex boundary checks,
and 'cancel' token support at all prompts to prevent program crashes.
"""

import re
from datetime import datetime
from typing import Optional, Tuple, Dict, Any, List

from src.models import Category, Urgency, Status

# Validation Regex Constants
EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
PHONE_REGEX = re.compile(r"^\+?[0-9\s\-()]{7,20}$")
SAFE_TEXT_REGEX = re.compile(r"^[\w\s\.,!\?@#%&()'\":;\-/]+$")


class ValidationError(ValueError):
    """Custom exception raised when input fails domain constraints."""
    pass


def is_cancel_token(value: str) -> bool:
    """Checks whether user entered a termination/cancellation command."""
    if not value:
        return False
    return value.strip().lower() in {"cancel", ":q", "exit", "quit", "abort"}


def sanitize_string(val: str, max_length: int = 500) -> str:
    """Sanitizes raw string by stripping control characters and trimming length."""
    if val is None:
        return ""
    # Remove null bytes and dangerous control characters while preserving newlines
    cleaned = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]", "", str(val)).strip()
    return cleaned[:max_length]


def validate_title(title: str) -> Tuple[bool, str]:
    """Validates request title length and character content."""
    clean = sanitize_string(title, max_length=150)
    if not clean:
        return False, "Title cannot be empty or whitespace only."
    if len(clean) < 3:
        return False, "Title must be at least 3 characters long."
    if len(clean) > 150:
        return False, "Title cannot exceed 150 characters."
    return True, clean


def validate_description(desc: str) -> Tuple[bool, str]:
    """Validates request description."""
    clean = sanitize_string(desc, max_length=2000)
    if not clean:
        return False, "Description cannot be empty."
    if len(clean) < 5:
        return False, "Description must be at least 5 characters long."
    return True, clean


def validate_category(cat: str) -> Tuple[bool, str]:
    """Validates category against recognized domain enums with case insensitivity."""
    clean = sanitize_string(cat, 50)
    for valid in Category.list_values():
        if clean.lower() == valid.lower():
            return True, valid
    valid_list = ", ".join(Category.list_values())
    return False, f"Invalid category '{clean}'. Allowed: {valid_list}"


def validate_urgency(urgency: str) -> Tuple[bool, str]:
    """Validates urgency against recognized levels."""
    clean = sanitize_string(urgency, 20)
    for valid in Urgency.list_values():
        if clean.lower() == valid.lower():
            return True, valid
    valid_list = ", ".join(Urgency.list_values())
    return False, f"Invalid urgency '{clean}'. Allowed: {valid_list}"


def validate_status(status: str) -> Tuple[bool, str]:
    """Validates status transition values."""
    clean = sanitize_string(status, 20)
    for valid in Status.list_values():
        if clean.lower() == valid.lower():
            return True, valid
    valid_list = ", ".join(Status.list_values())
    return False, f"Invalid status '{clean}'. Allowed: {valid_list}"


def validate_contact(contact: str) -> Tuple[bool, str]:
    """Validates requester contact info (must match email, phone, or campus handle)."""
    clean = sanitize_string(contact, 100)
    if not clean:
        return False, "Contact information cannot be blank."
    if EMAIL_REGEX.match(clean) or PHONE_REGEX.match(clean) or (clean.startswith("@") and len(clean) >= 3):
        return True, clean
    return False, "Contact must be a valid email, phone number (min 7 digits), or @handle."


def validate_deadline(deadline_str: Optional[str]) -> Tuple[bool, Optional[str]]:
    """Validates deadline date in YYYY-MM-DD format."""
    if not deadline_str or not deadline_str.strip():
        return True, None
    clean = deadline_str.strip()
    try:
        dt = datetime.strptime(clean, "%Y-%m-%d").date()
        return True, dt.strftime("%Y-%m-%d")
    except ValueError:
        return False, "Deadline must be formatted strictly as YYYY-MM-DD."


def validate_request_payload(data: Dict[str, Any]) -> Tuple[bool, Dict[str, Any], List[str]]:
    """
    Comprehensively validates a full record payload dictionary.
    Returns (is_valid, sanitized_dict, error_messages).
    """
    errors: List[str] = []
    sanitized: Dict[str, Any] = {}

    # Title
    ok, res = validate_title(data.get("title", ""))
    if not ok:
        errors.append(res)
    else:
        sanitized["title"] = res

    # Description
    ok, res = validate_description(data.get("description", ""))
    if not ok:
        errors.append(res)
    else:
        sanitized["description"] = res

    # Category
    ok, res = validate_category(data.get("category", Category.MISCELLANEOUS.value))
    if not ok:
        errors.append(res)
    else:
        sanitized["category"] = res

    # Urgency
    ok, res = validate_urgency(data.get("urgency", Urgency.MEDIUM.value))
    if not ok:
        errors.append(res)
    else:
        sanitized["urgency"] = res

    # Status
    status_val = data.get("status", Status.OPEN.value)
    ok, res = validate_status(status_val)
    if not ok:
        errors.append(res)
    else:
        sanitized["status"] = res

    # Requester
    req_name = sanitize_string(data.get("requester", ""), 100)
    if not req_name:
        errors.append("Requester name or ID cannot be empty.")
    else:
        sanitized["requester"] = req_name

    # Location
    loc = sanitize_string(data.get("location", ""), 150)
    if not loc:
        errors.append("Location cannot be empty.")
    else:
        sanitized["location"] = loc

    # Contact
    ok, res = validate_contact(data.get("contact", ""))
    if not ok:
        errors.append(res)
    else:
        sanitized["contact"] = res

    # Deadline
    ok, res = validate_deadline(data.get("deadline"))
    if not ok:
        errors.append(res)
    else:
        sanitized["deadline"] = res

    # Passthrough optional fields
    if "id" in data:
        sanitized["id"] = data["id"]
    if "created_at" in data:
        sanitized["created_at"] = data["created_at"]
    if "updated_at" in data:
        sanitized["updated_at"] = data["updated_at"]
    if "tags" in data:
        sanitized["tags"] = data["tags"]

    return len(errors) == 0, sanitized, errors
