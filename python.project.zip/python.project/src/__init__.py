"""
StudentLife Hack - Community Help Request Board
Source Package
"""
__version__ = "2.0.0"
__author__ = "Community Help Request Board Team"
