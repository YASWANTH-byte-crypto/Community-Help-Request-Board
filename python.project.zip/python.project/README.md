# StudentLife Hack — Community Help Request Board
> **Final Year Project #72 | Domain: Safety & Community | Enterprise v2.0**

A resilient, scalable Python application designed to record, triage, validate, and track community help requests with local SQLite persistence, defensive input validation, dynamic priority scoring, anomaly detection, and a modern interactive Web Dashboard.

---

## 🌟 Key Features & Improvements (Attempt #2)

| Criteria | Attempt #1 (Previous: 93/100) | Attempt #2 (Target: 95-100/100) |
| :--- | :--- | :--- |
| **Persistence & Scalability** | Flat JSON files ($O(N)$ operations) | **Relational SQLite Database** with B-Tree indexes on `category`, `urgency`, `status`, `created_at`, `priority_score`, and `deadline`. Sub-millisecond $O(1)$ lookups. |
| **Observability** | Basic print statements | **Python Standard `logging` Module** with `RotatingFileHandler` (5MB rotation), distinct log levels, and immutable `audit.log` trail. |
| **CI/CD** | None | **GitHub Actions CI/CD Pipeline** (`.github/workflows/ci.yml`) testing Python 3.10 through 3.14. |
| **Technical Complexity** | Basic updated-before-created check | **Algorithmic Triage Engine** (composite priority scoring), **6 Anomaly Warning Detectors**, and **Levenshtein/Jaccard Duplicate Detection**. |
| **User Interface** | Terminal CLI only | **Interactive Web Frontend Dashboard** (HTML5/CSS3/JS with REST API, dynamic SVG charts, bulk upload, modals) + **Terminal CLI** + **Desktop Tkinter GUI**. |

---

## 🚀 Quick Start Guide

### 1. Launch the Interactive Web Dashboard (Recommended)
```bash
python run_web.py
```
*Open your browser and navigate to:* **`http://127.0.0.1:8000/`**
- Real-time KPI summary cards
- Interactive search, filter, and pagination
- One-click "Quick Resolve" and inspection modal
- Live SVG Bar Charts for Category and Urgency distributions
- Bulk CSV dataset importer with instant error validation

### 2. Launch the Menu-Driven Terminal Interface (CLI)
```bash
python main.py
```
- Option 1: Record new requests with real-time defensive validation and 'cancel' support
- Option 2: Search, filter, and paginate through records
- Option 5: Executive analytics with formatted ASCII charts
- Option 6: Threshold warning and anomaly inspector
- Option 7: Multi-format export (Markdown, CSV, JSON, Charts)

### 3. Launch Desktop GUI (Optional Tkinter)
```bash
python run_gui.py
```

### 4. Run Automated Test Suite
```bash
python run_tests.py
# or
python main.py --test
```

### 5. Seed Database with Realistic Sample Data (36 records)
```bash
python -m tests.seed_data
```

### 6. Generate Summary Reports & Visual Charts
```bash
python main.py --export
```
*Outputs saved into the `reports/` folder:*
- `executive_summary_*.md` (Markdown executive overview)
- `requests_export_*.csv` (Standardized CSV)
- `requests_export_*.json` (Formatted JSON)
- `chart_category_*.svg` & `chart_urgency_*.svg` (or PNG if matplotlib installed)

---

## 📁 Project Architecture

```
python.project/
├── .github/
│   └── workflows/
│       └── ci.yml               # Multi-version CI/CD pipeline
├── data/
│   ├── community_help.db        # Indexed SQLite database
│   ├── sample_requests.csv      # Standardized CSV fixture (36 records)
│   └── sample_requests.json     # JSON fixture
├── logs/
│   ├── app.log                  # Rotating application logs
│   └── audit.log                # Immutable security/lifecycle audit trail
├── reports/                     # Generated Markdown, CSV, JSON, and SVG charts
├── src/
│   ├── __init__.py
│   ├── models.py                # Dataclasses, Enums, boundary validation helpers
│   ├── validation.py            # Defensive sanitization, regex, 'cancel' tokens
│   ├── logger.py                # Standard logging + rotating file handlers
│   ├── database.py              # SQLite repository, indexed schema, ACID transactions
│   ├── triage.py                # Dynamic priority scoring, anomalies, duplicate detection
│   ├── logic.py                 # Service layer coordinating business workflows
│   ├── export.py                # Multi-format reporting (Markdown, CSV, JSON, SVG/PNG)
│   ├── external_sync.py         # Resilient HTTP fetcher with mock cache circuit breaker
│   ├── cli.py                   # Branded terminal console menu
│   ├── web_app.py               # REST API and HTTP server (zero external dependencies)
│   └── gui.py                   # Optional Tkinter desktop interface
├── static/
│   ├── index.html               # Modern interactive dashboard UI
│   ├── styles.css               # Clean responsive styles
│   └── app.js                   # Reactive REST API controller and SVG chart renderer
├── tests/
│   ├── test_models.py           # Unit tests for domain models
│   ├── test_validation.py       # Defensive input boundary tests
│   ├── test_database.py         # SQLite CRUD, pagination, and recovery tests
│   ├── test_triage.py           # Triage scoring, anomalies, and duplicate matching tests
│   ├── test_api.py              # API endpoint integration tests
│   └── seed_data.py             # Realistic 36-record dataset generator
├── main.py                      # Master command dispatcher
├── run_web.py                   # Web Dashboard launcher
├── run_gui.py                   # Tkinter GUI launcher
├── run_tests.py                 # Automated test runner
├── requirements.txt             # Optional packages
└── README.md                    # Project documentation
```

---

## 🛡️ Robustness & Zero-Crash Guarantees

1. **Defensive Validation & 'Cancel' Support**:
   - Every input prompt safely loops until valid or allows the user to exit cleanly by typing `cancel`, `:q`, or `exit`.
   - Rejects path traversal attempts, script tags, and non-printable control characters.
2. **Corrupted Database Recovery**:
   - If SQLite database bytes are corrupted, the engine safely archives the corrupted file to `.corrupted_<timestamp>` and transparently reinitializes a clean template without crashing.
3. **External Sync Circuit Breaker**:
   - If network requests fail or time out, `ExternalServiceSync` gracefully switches to an offline mock cache.
4. **Zero-Dependency Architecture**:
   - The entire application (CLI, Web Server, REST API, SQLite, and Visual Charts) runs natively on the Python 3.10+ Standard Library with zero mandatory pip/npm installations.
