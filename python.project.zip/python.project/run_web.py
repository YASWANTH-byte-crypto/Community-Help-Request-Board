"""
Interactive Web Application Server Launcher
Starts the embedded HTTP REST API and serves the responsive modern dashboard.
Zero external dependencies required.
"""

import sys
import os
import webbrowser
from src.web_app import run_web_server

if __name__ == "__main__":
    port = 8000
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        port = int(sys.argv[1])
    print(f"Starting StudentLife Hack Web Dashboard on port {port}...")
    run_web_server(port=port)
