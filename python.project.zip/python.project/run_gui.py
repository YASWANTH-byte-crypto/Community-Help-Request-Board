"""
Launcher for Desktop GUI (Tkinter)
"""
import sys
from src.gui import run_gui_app

if __name__ == "__main__":
    run_gui_app()
