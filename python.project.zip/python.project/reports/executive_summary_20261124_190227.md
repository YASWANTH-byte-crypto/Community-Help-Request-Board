# StudentLife Hack — Community Help Request Board
**Generated:** 2026-11-24 19:02:27
**Total Records:** 72
**Average Triage Priority Score:** 71.38
**Overdue Requests:** 12

## 1. Status Breakdown
| Status | Count |
| :--- | :--- |
| Open | 28 |
| In Progress | 18 |
| Resolved | 18 |
| Cancelled | 8 |

## 2. Urgency Breakdown
| Urgency Level | Count |
| :--- | :--- |
| Low | 18 |
| Medium | 16 |
| High | 24 |
| Critical | 14 |

## 3. Category Distribution
| Category | Count |
| :--- | :--- |
| Academic | 10 |
| Food & Essentials | 10 |
| Health & Safety | 10 |
| Housing & Utilities | 12 |
| Mental Health | 6 |
| Miscellaneous | 6 |
| Technical & Hardware | 10 |
| Transportation | 8 |

## 4. Anomalies & Warnings
### Individual Record Anomalies
- **Request #40** ('First Aid kit restock needed urgently for Engineering Makerspace'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 48.0 hours without intervention.
- **Request #4** ('First Aid kit restock needed urgently for Engineering Makerspace'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 48.1 hours without intervention.
- **Request #48** ('Broken window latch on ground floor apartment'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'In Progress'.
- **Request #12** ('Broken window latch on ground floor apartment'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'In Progress'.
- **Request #37** ('Need tutor for CS301 Discrete Mathematics proof techniques'):
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 48.0 hours without intervention.
- **Request #1** ('Need tutor for CS301 Discrete Mathematics proof techniques'):
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 48.1 hours without intervention.
- **Request #46** ('Water leak beneath sink in Spruce Hall Room 302'):
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 30.0 hours without intervention.
- **Request #10** ('Water leak beneath sink in Spruce Hall Room 302'):
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 30.1 hours without intervention.
- **Request #58** ('Community Request #22: Housing & Utilities assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #22** ('Community Request #22: Housing & Utilities assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #62** ('Community Request #26: Academic assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #26** ('Community Request #26: Academic assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #66** ('Community Request #30: Housing & Utilities assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #30** ('Community Request #30: Housing & Utilities assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #70** ('Community Request #34: Academic assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #34** ('Community Request #34: Academic assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #54** ('Anomalous entry with inverted timestamp for audit testing'):
  - `[HIGH]` Updated timestamp (2026-11-22T13:32:26.550638+00:00) precedes Creation timestamp (2026-11-24T13:32:26.550638+00:00).
- **Request #18** ('Anomalous entry with inverted timestamp for audit testing'):
  - `[HIGH]` Updated timestamp (2026-11-22T13:29:17.435709+00:00) precedes Creation timestamp (2026-11-24T13:29:17.435709+00:00).