# StudentLife Hack — Community Help Request Board
**Generated:** 2026-11-24 18:59:17
**Total Records:** 36
**Average Triage Priority Score:** 71.38
**Overdue Requests:** 6

## 1. Status Breakdown
| Status | Count |
| :--- | :--- |
| Open | 14 |
| In Progress | 9 |
| Resolved | 9 |
| Cancelled | 4 |

## 2. Urgency Breakdown
| Urgency Level | Count |
| :--- | :--- |
| Low | 9 |
| Medium | 8 |
| High | 12 |
| Critical | 7 |

## 3. Category Distribution
| Category | Count |
| :--- | :--- |
| Academic | 5 |
| Food & Essentials | 5 |
| Health & Safety | 5 |
| Housing & Utilities | 6 |
| Mental Health | 3 |
| Miscellaneous | 3 |
| Technical & Hardware | 5 |
| Transportation | 4 |

## 4. Anomalies & Warnings
### Individual Record Anomalies
- **Request #4** ('First Aid kit restock needed urgently for Engineering Makerspace'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 48.0 hours without intervention.
- **Request #12** ('Broken window latch on ground floor apartment'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'In Progress'.
- **Request #1** ('Need tutor for CS301 Discrete Mathematics proof techniques'):
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 48.0 hours without intervention.
- **Request #10** ('Water leak beneath sink in Spruce Hall Room 302'):
  - `[HIGH]` High/Critical urgency request has remained in 'Open' status for 30.0 hours without intervention.
- **Request #22** ('Community Request #22: Housing & Utilities assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #26** ('Community Request #26: Academic assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #30** ('Community Request #30: Housing & Utilities assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #34** ('Community Request #34: Academic assistance for student group'):
  - `[CRITICAL]` Task deadline (2026-11-23) has expired but status is still 'Open'.
- **Request #18** ('Anomalous entry with inverted timestamp for audit testing'):
  - `[HIGH]` Updated timestamp (2026-11-22T13:29:17.435709+00:00) precedes Creation timestamp (2026-11-24T13:29:17.435709+00:00).