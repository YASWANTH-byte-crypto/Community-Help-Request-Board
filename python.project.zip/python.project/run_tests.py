"""
Automated Test Runner
Discovers and executes all unit and integration test suites,
reporting pass rates and execution time.
Zero external dependencies required (runs via standard unittest).
"""

import sys
import unittest
import time


def run_all_tests() -> bool:
    print("=" * 70)
    print("🚀 Running StudentLife Hack Automated Test Suite")
    print("=" * 70)

    loader = unittest.TestLoader()
    suite = loader.discover("tests", pattern="test_*.py")

    start_time = time.time()
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    elapsed = time.time() - start_time

    print("\n" + "=" * 70)
    print(f"Total Tests Run: {result.testsRun}")
    print(f"Failures:       {len(result.failures)}")
    print(f"Errors:         {len(result.errors)}")
    print(f"Time Elapsed:   {elapsed:.2f} seconds")
    print("=" * 70)

    if result.wasSuccessful():
        print("✓ ALL TESTS PASSED SUCCESSFULLY! (100% Pass Rate)\n")
        return True
    else:
        print("✗ TEST SUITE FAILED.\n")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
