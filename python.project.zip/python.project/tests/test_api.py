"""
Integration Tests for REST API Endpoints and Service Layer
"""

import unittest
import json
import tempfile
import os
from src.database import DatabaseManager
from src.logic import HelpRequestService
from src.models import Category, Urgency


class TestApiService(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "api_test.db")
        self.db = DatabaseManager(self.db_path)
        self.service = HelpRequestService(self.db)

    def tearDown(self):
        import gc
        gc.collect()
        try:
            self.temp_dir.cleanup()
        except Exception:
            pass

    def test_create_and_resolve_flow(self):
        payload = {
            "title": "Need TI-84 calculator for exam",
            "description": "Calculus midterm exam tomorrow afternoon",
            "category": Category.ACADEMIC.value,
            "urgency": Urgency.HIGH.value,
            "requester": "Student Mark",
            "location": "Library 1st floor",
            "contact": "mark@campus.edu",
            "deadline": "2026-12-01"
        }
        ok, res, dups = self.service.create_request(payload)
        self.assertTrue(ok)
        self.assertIsNotNone(res.id)
        self.assertGreater(res.priority_score, 0)

        # Quick Resolve
        resolved_ok, msg = self.service.resolve_request(res.id, "Loaned calculator")
        self.assertTrue(resolved_ok)

        # Check status
        updated = self.db.get_by_id(res.id)
        self.assertEqual(updated.status, "Resolved")
        self.assertIn("Loaned calculator", updated.description)

    def test_csv_import_workflow(self):
        csv_data = """title,description,category,urgency,requester,location,contact,deadline
Calculus tutor,Need assistance with integrals,Academic,Medium,John Doe,Library 2B,john@campus.edu,2026-12-01
Broken latch,Door latch loose,Housing & Utilities,Low,Jane Doe,Room 101,555-0199,2026-12-05
"""
        res = self.service.import_csv_dataset(csv_data)
        self.assertEqual(res["success_count"], 2)
        self.assertEqual(res["failed_count"], 0)

        stats = self.service.get_executive_summary()
        self.assertEqual(stats["total_records"], 2)


if __name__ == "__main__":
    unittest.main()
