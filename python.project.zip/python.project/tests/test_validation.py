"""
Unit Tests for Defensive Input Validation Engine
"""

import unittest
from src.validation import (
    validate_title, validate_description, validate_category,
    validate_urgency, validate_contact, validate_deadline,
    is_cancel_token, validate_request_payload
)


class TestValidationEngine(unittest.TestCase):

    def test_cancel_token_detection(self):
        self.assertTrue(is_cancel_token("cancel"))
        self.assertTrue(is_cancel_token("CANCEL"))
        self.assertTrue(is_cancel_token(":q"))
        self.assertTrue(is_cancel_token("exit"))
        self.assertFalse(is_cancel_token("normal input"))
        self.assertFalse(is_cancel_token(""))

    def test_title_boundary_validation(self):
        # Empty title
        ok, _ = validate_title("")
        self.assertFalse(ok)

        # Whitespace only
        ok, _ = validate_title("   ")
        self.assertFalse(ok)

        # Too short (< 3 chars)
        ok, _ = validate_title("ab")
        self.assertFalse(ok)

        # Valid title
        ok, clean = validate_title("Need help with physics homework")
        self.assertTrue(ok)
        self.assertEqual(clean, "Need help with physics homework")

    def test_contact_formats(self):
        # Valid email
        ok, _ = validate_contact("student@campus.edu")
        self.assertTrue(ok)

        # Valid phone
        ok, _ = validate_contact("555-019-2834")
        self.assertTrue(ok)
        ok, _ = validate_contact("+1 (555) 019-2834")
        self.assertTrue(ok)

        # Valid social handle
        ok, _ = validate_contact("@campus_volunteer")
        self.assertTrue(ok)

        # Invalid contact
        ok, _ = validate_contact("invalid_handle_without_symbol")
        self.assertFalse(ok)

    def test_category_and_urgency_enums(self):
        ok, clean = validate_category("academic")
        self.assertTrue(ok)
        self.assertEqual(clean, "Academic")

        ok, _ = validate_category("NonExistentCategory")
        self.assertFalse(ok)

        ok, clean = validate_urgency("critical")
        self.assertTrue(ok)
        self.assertEqual(clean, "Critical")

        ok, _ = validate_urgency("UltraExtreme")
        self.assertFalse(ok)

    def test_deadline_date_formatting(self):
        ok, val = validate_deadline("2026-12-31")
        self.assertTrue(ok)
        self.assertEqual(val, "2026-12-31")

        # Invalid format
        ok, _ = validate_deadline("12/31/2026")
        self.assertFalse(ok)

        ok, _ = validate_deadline("not-a-date")
        self.assertFalse(ok)

        # Optional None/empty
        ok, val = validate_deadline("")
        self.assertTrue(ok)
        self.assertIsNone(val)

    def test_full_payload_validation(self):
        valid_payload = {
            "title": "Broken window in library",
            "description": "Latches broken on 2nd floor study carrel",
            "category": "Housing & Utilities",
            "urgency": "Medium",
            "requester": "Dana Scully",
            "location": "Library Room 204",
            "contact": "scully@fbi.gov",
            "deadline": "2026-12-15"
        }
        ok, sanitized, errors = validate_request_payload(valid_payload)
        self.assertTrue(ok)
        self.assertEqual(len(errors), 0)
        self.assertEqual(sanitized["title"], "Broken window in library")


if __name__ == "__main__":
    unittest.main()
