"""
Unit Tests for SQLite Relational Database Persistence Layer
Tests O(1) indexed lookups, pagination, ACID transactions, and auto-recovery.
"""

import unittest
import os
import tempfile
from src.database import DatabaseManager
from src.models import HelpRequest, Category, Urgency, Status


class TestDatabaseManager(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "test_community.db")
        self.db = DatabaseManager(self.db_path)

    def tearDown(self):
        import gc
        gc.collect()
        try:
            self.temp_dir.cleanup()
        except Exception:
            pass

    def test_create_and_get_by_id(self):
        req = HelpRequest(
            title="Database test ticket",
            description="Testing SQLite storage",
            category=Category.ACADEMIC.value,
            urgency=Urgency.HIGH.value,
            requester="Tester",
            location="Lab A",
            contact="tester@campus.edu"
        )
        saved = self.db.create(req)
        self.assertIsNotNone(saved.id)

        fetched = self.db.get_by_id(saved.id)
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched.title, "Database test ticket")
        self.assertEqual(fetched.urgency, Urgency.HIGH.value)

    def test_update_and_delete(self):
        req = HelpRequest(
            title="Mutable request",
            description="Will be updated",
            category=Category.TECH_HARDWARE.value,
            urgency=Urgency.LOW.value,
            requester="User1",
            location="Hall B",
            contact="user1@campus.edu"
        )
        saved = self.db.create(req)

        # Update
        saved.status = Status.RESOLVED.value
        updated = self.db.update(saved)
        self.assertTrue(updated)

        refetched = self.db.get_by_id(saved.id)
        self.assertEqual(refetched.status, Status.RESOLVED.value)

        # Delete
        deleted = self.db.delete(saved.id)
        self.assertTrue(deleted)
        self.assertIsNone(self.db.get_by_id(saved.id))

    def test_filtered_query_and_pagination(self):
        for i in range(15):
            cat = Category.ACADEMIC.value if i % 2 == 0 else Category.FOOD_ESSENTIALS.value
            req = HelpRequest(
                title=f"Sample Request #{i}",
                description=f"Description for #{i}",
                category=cat,
                urgency=Urgency.MEDIUM.value,
                requester=f"Student {i}",
                location="Campus",
                contact=f"student{i}@campus.edu"
            )
            self.db.create(req)

        # Pagination test: limit 5, offset 0
        p1, total = self.db.get_all(limit=5, offset=0)
        self.assertEqual(len(p1), 5)
        self.assertEqual(total, 15)

        # Filter by category
        acad_items, acad_count = self.db.get_all(category=Category.ACADEMIC.value)
        self.assertEqual(acad_count, 8)
        self.assertEqual(len(acad_items), 8)

    def test_corruption_recovery(self):
        # Corrupt DB file with junk bytes
        with open(self.db_path, "wb") as f:
            f.write(b"CORRUPTED BYTES RANDOM NOT SQLITE DATA 123456789")

        # DatabaseManager should detect corruption and cleanly reinitialize
        recovered_db = DatabaseManager(self.db_path)
        stats = recovered_db.get_summary_stats()
        self.assertEqual(stats["total_records"], 0)


if __name__ == "__main__":
    unittest.main()
