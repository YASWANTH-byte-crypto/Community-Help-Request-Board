"""
Unit Tests for Algorithmic Triage, Anomaly Warnings, and Duplicate Matching
"""

import unittest
from datetime import datetime, timezone, timedelta
from src.models import HelpRequest, Category, Urgency, Status
from src.triage import TriageEngine, AnomalyEngine, SimilarityEngine


class TestTriageAndAnomalies(unittest.TestCase):

    def test_priority_score_calculation(self):
        now = datetime.now(timezone.utc)

        # Low urgency item
        low_req = HelpRequest(
            title="Book lending",
            description="Looking for textbook",
            category=Category.ACADEMIC.value,
            urgency=Urgency.LOW.value,
            requester="Sam",
            location="Dorm",
            contact="sam@campus.edu"
        )
        low_score = TriageEngine.calculate_priority_score(low_req)

        # Critical urgency item with emergency keyword
        crit_req = HelpRequest(
            title="Emergency medical assistance",
            description="Immediate first aid supplies required",
            category=Category.HEALTH_SAFETY.value,
            urgency=Urgency.CRITICAL.value,
            requester="Staff",
            location="Gym",
            contact="555-0199"
        )
        crit_score = TriageEngine.calculate_priority_score(crit_req)

        self.assertGreater(crit_score, low_score)
        self.assertGreaterEqual(crit_score, 120.0)

    def test_anomaly_detection_timeline_inversion(self):
        now = datetime.now(timezone.utc)
        req = HelpRequest(
            title="Inverted timestamp ticket",
            description="Created after updated",
            category=Category.MISCELLANEOUS.value,
            urgency=Urgency.LOW.value,
            requester="Tester",
            location="Lab",
            contact="test@campus.edu",
            created_at=now.isoformat(),
            updated_at=(now - timedelta(days=2)).isoformat()
        )
        warnings = AnomalyEngine.inspect_request(req)
        w_types = [w["type"] for w in warnings]
        self.assertIn("TIMELINE_INVERSION", w_types)

    def test_anomaly_detection_sla_breach_risk(self):
        two_days_ago = (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
        req = HelpRequest(
            title="Critical unattended help request",
            description="Unresolved for 48 hours",
            category=Category.HEALTH_SAFETY.value,
            urgency=Urgency.CRITICAL.value,
            status=Status.OPEN.value,
            requester="Tester",
            location="Lab",
            contact="test@campus.edu",
            created_at=two_days_ago
        )
        warnings = AnomalyEngine.inspect_request(req)
        w_types = [w["type"] for w in warnings]
        self.assertIn("SLA_BREACH_RISK", w_types)

    def test_duplicate_similarity_detection(self):
        req1 = HelpRequest(
            id=1,
            title="Water leak under sink in Spruce Hall 302",
            description="Water is dripping and creating puddle",
            category=Category.HOUSING_UTILITIES.value,
            urgency=Urgency.HIGH.value,
            requester="User A",
            location="Spruce 302",
            contact="a@campus.edu"
        )
        existing = [req1]

        # Candidate with near identical wording
        candidate_title = "Water leak under bathroom sink in Spruce 302"
        candidate_desc = "Sink is leaking water on the floor"

        duplicates = SimilarityEngine.find_potential_duplicates(
            candidate_title, candidate_desc, existing, threshold=0.55
        )
        self.assertEqual(len(duplicates), 1)
        match_req, score = duplicates[0]
        self.assertEqual(match_req.id, 1)
        self.assertGreaterEqual(score, 0.55)


if __name__ == "__main__":
    unittest.main()
