"""
Unit Tests for Domain Data Models
"""

import unittest
from datetime import datetime, timezone, timedelta
from src.models import HelpRequest, Category, Urgency, Status


class TestHelpRequestModels(unittest.TestCase):

    def test_model_instantiation_defaults(self):
        req = HelpRequest(
            title="Lab equipment loan",
            description="Borrow oscilloscope for circuits lab",
            category=Category.TECH_HARDWARE.value,
            urgency=Urgency.MEDIUM.value,
            requester="Alice",
            location="Room 101",
            contact="alice@campus.edu"
        )
        self.assertIsNone(req.id)
        self.assertEqual(req.status, Status.OPEN.value)
        self.assertIsNotNone(req.created_at)
        self.assertFalse(req.is_overdue())

    def test_overdue_calculation(self):
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")

        # Open and past deadline -> overdue
        overdue_req = HelpRequest(
            title="Late ticket",
            description="Test overdue",
            category=Category.ACADEMIC.value,
            urgency=Urgency.HIGH.value,
            requester="Bob",
            location="Library",
            contact="bob@campus.edu",
            deadline=yesterday,
            status=Status.OPEN.value
        )
        self.assertTrue(overdue_req.is_overdue())

        # Resolved and past deadline -> NOT overdue
        resolved_req = HelpRequest(
            title="Late but done",
            description="Test resolved",
            category=Category.ACADEMIC.value,
            urgency=Urgency.HIGH.value,
            requester="Bob",
            location="Library",
            contact="bob@campus.edu",
            deadline=yesterday,
            status=Status.RESOLVED.value
        )
        self.assertFalse(resolved_req.is_overdue())

        # Due tomorrow -> NOT overdue
        future_req = HelpRequest(
            title="Future ticket",
            description="Test future",
            category=Category.ACADEMIC.value,
            urgency=Urgency.HIGH.value,
            requester="Bob",
            location="Library",
            contact="bob@campus.edu",
            deadline=tomorrow,
            status=Status.OPEN.value
        )
        self.assertFalse(future_req.is_overdue())

    def test_dict_serialization_and_deserialization(self):
        original = HelpRequest(
            title="Serialization test",
            description="Check round trip conversion",
            category=Category.FOOD_ESSENTIALS.value,
            urgency=Urgency.CRITICAL.value,
            requester="Charlie",
            location="Cafeteria",
            contact="555-0199",
            tags=["food", "test"]
        )
        d = original.to_dict()
        reconstructed = HelpRequest.from_dict(d)

        self.assertEqual(original.title, reconstructed.title)
        self.assertEqual(original.category, reconstructed.category)
        self.assertEqual(original.urgency, reconstructed.urgency)
        self.assertEqual(original.tags, reconstructed.tags)


if __name__ == "__main__":
    unittest.main()
