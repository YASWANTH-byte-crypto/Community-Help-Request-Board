"""
Application Main Launcher
Entrypoint supporting CLI interactive mode, web dashboard server,
test runner, and database seed generation.
"""

import sys
import argparse
from src.logger import setup_logger, get_logger

setup_logger()


def main():
    parser = argparse.ArgumentParser(description="StudentLife Hack - Community Help Request Board")
    parser.add_argument("--cli", action="store_true", help="Launch interactive terminal CLI interface (default)")
    parser.add_argument("--web", action="store_true", help="Launch interactive Web Dashboard")
    parser.add_argument("--port", type=int, default=8000, help="Port for Web Dashboard server (default: 8000)")
    parser.add_argument("--seed", action="store_true", help="Seed database with realistic sample dataset")
    parser.add_argument("--test", action="store_true", help="Run automated test suite")
    parser.add_argument("--export", action="store_true", help="Generate all summary reports and charts")

    args = parser.parse_args()

    if args.seed:
        from tests.seed_data import seed_database
        seed_database()
        print("Database seeded with realistic sample records.")
        return

    if args.test:
        from run_tests import run_all_tests
        success = run_all_tests()
        sys.exit(0 if success else 1)

    if args.export:
        from src.logic import HelpRequestService
        from src.export import export_markdown_report, export_csv_data, export_json_data, generate_visual_charts
        srv = HelpRequestService()
        stats = srv.get_executive_summary()
        warns = srv.get_warnings_and_anomalies()
        reqs, _ = srv.db.get_all(limit=1000)
        export_markdown_report(stats, warns)
        export_csv_data(reqs)
        export_json_data(reqs)
        generate_visual_charts(stats)
        print("Summary reports and charts successfully generated in reports/ directory.")
        return

    if args.web:
        from src.web_app import run_web_server
        run_web_server(port=args.port)
        return

    # Default to CLI
    from src.cli import TerminalCLI
    cli = TerminalCLI()
    cli.run()


if __name__ == "__main__":
    main()
